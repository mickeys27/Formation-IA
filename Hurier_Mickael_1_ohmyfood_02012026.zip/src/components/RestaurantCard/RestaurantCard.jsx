"use client"; //Pour utiliser useState, il faut déclarer le composant comme Client Component avec "use client".”
import { useState } from "react"; // pour la gestion du like
import styles from "./RestaurantCard.module.css";

//Plus de texte “en dur” : tout vient de restaurant.
export default function RestaurantCard({ restaurant }) {
  const { name, location, image, isNew } = restaurant;
  const [liked, setLiked] = useState(false);

  const handleLike = () => {
    setLiked((prev) => !prev);// gestion du like
  };

  return (
    <article className={styles.card}>
      <div className={styles.imageWrap}>
        {isNew && <span className={styles.badge}>Nouveau</span>}
        <img src={image} alt={name} className={styles.image} />
      </div>

      <div className={styles.content}>
        <div className={styles.text}>
          <h3 className={styles.title}>{name}</h3>
          <p className={styles.subtitle}>{location}</p>
        </div>

        <button
          className={`${styles.heart} ${liked ? styles.liked : ""}`}
          onClick={handleLike}
          aria-label="Ajouter aux favoris"
        />
      </div>
    </article>
  );
}