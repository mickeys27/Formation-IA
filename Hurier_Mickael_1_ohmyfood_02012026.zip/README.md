# Ohmyfood Next.js

Starting project for Ohmyfood. 

You can run project following the steps : 
1. in you terminal write `npm install` (you need to do this only one time)
2. write `npm run dev` to run the project