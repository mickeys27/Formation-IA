require('dotenv').config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const router = require("./routes");
const aiRouter = require("./routes-ai");

const app = express();
app.use(cors());
app.use(bodyParser.json());
const port = process.env.PORT || 8000;

app.use(router);
app.use(aiRouter);

router.use('/images', express.static('images'));

app.listen(port, () => console.log(`Magic happens on port ${port}`));
