const express = require("express");
const { Mistral } = require("@mistralai/mistralai");

const users = require("./data.json");
const { authenticateToken } = require("./middleware");

const router = express.Router();

// Initialize Mistral client
const mistralClient = new Mistral({
  apiKey: process.env.MISTRAL_API_KEY,
});

const getUserById = (userId) => {
  return users.find((user) => user.id === userId);
};

/**
 * POST /api/ai/program
 * Generates a 6-week training program using Mistral AI
 * Body: { objective, startDate }
 */
router.post("/api/ai/training-plan", authenticateToken, async (req, res) => {
  try {
    const { objective, startDate } = req.body;

    // Validation
    if (!objective || !startDate) {
      return res.status(400).json({ 
        message: "objective and startDate are required" 
      });
    }

    // Validate date format
    const parsedDate = new Date(startDate);
    if (isNaN(parsedDate.getTime())) {
      return res.status(400).json({ 
        message: "Invalid date format. Use YYYY-MM-DD" 
      });
    }

    // Sanitize inputs (basic XSS protection)
    const sanitizedObjective = objective.trim().substring(0, 500);
    const sanitizedStartDate = startDate.trim();

    // Get user data for personalization
    const user = getUserById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Calculate user statistics
    const runningData = user.runningData;
    const totalDistance = runningData.reduce(
      (sum, session) => sum + session.distance,
      0
    ).toFixed(1);
    const totalSessions = runningData.length;
    const avgDistance = (totalDistance / totalSessions).toFixed(1);

    // Build the prompt for Mistral
    const prompt = `Tu es un coach sportif professionnel spécialisé en course à pied. 

Profil de l'utilisateur:
- Nom: ${user.userInfos.firstName} ${user.userInfos.lastName}
- Âge: ${user.userInfos.age} ans
- Poids: ${user.userInfos.weight} kg
- Taille: ${user.userInfos.height} cm
- Distance totale parcourue: ${totalDistance} km
- Nombre de sessions: ${totalSessions}
- Distance moyenne par session: ${avgDistance} km

Objectif: ${sanitizedObjective}
Date de début: ${sanitizedStartDate}

Crée un programme d'entraînement personnalisé sur 6 semaines (du ${sanitizedStartDate} à 6 semaines plus tard).

Format de réponse STRICTEMENT en JSON:
{
  "program": {
    "objective": "objectif reformulé",
    "startDate": "${sanitizedStartDate}",
    "duration": "6 semaines",
    "weeks": [
      {
        "weekNumber": 1,
        "weekTitle": "titre de la semaine",
        "sessions": [
          {
            "day": "Lundi",
            "title": "nom de l'exercice",
            "description": "description détaillée",
            "duration": 30,
            "intensity": "modérée",
            "targetMuscles": "jambes, cardio"
          }
        ]
      }
    ],
    "recommendations": [
      "conseil 1",
      "conseil 2",
      "conseil 3"
    ]
  }
}

Chaque semaine doit contenir 3-4 sessions variées. Adapte la difficulté progressivement.
Réponds UNIQUEMENT avec le JSON, sans texte avant ou après.`;

    console.log("[MISTRAL AI - PROGRAM] Sending request to Mistral AI...");
    
    // Call Mistral API with timeout
    const chatResponse = await Promise.race([
      mistralClient.chat.complete({
        model: "mistral-small-latest",
        messages: [
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        maxTokens: 4000,
      }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Request timeout")), 30000)
      )
    ]);

    if (!chatResponse.choices || chatResponse.choices.length === 0) {
      throw new Error("No response from Mistral AI");
    }

    const generatedContent = chatResponse.choices[0].message.content;
    console.log("[MISTRAL AI - PROGRAM] Response received successfully");

    // Parse JSON response
    let trainingProgram;
    try {
      // Remove potential markdown code blocks
      const cleanedContent = generatedContent
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim();
      
      trainingProgram = JSON.parse(cleanedContent);
    } catch (parseError) {
      console.error("[MISTRAL AI - PROGRAM] JSON parsing error:", parseError);
      // Return raw content if parsing fails
      return res.json({
        rawContent: generatedContent,
        message: "Program generated but format needs adjustment"
      });
    }

    return res.json({
      success: true,
      program: trainingProgram.program,
      metadata: {
        generatedAt: new Date().toISOString(),
        userId: user.id,
        model: "mistral-small-latest"
      }
    });

  } catch (error) {
    console.error("[MISTRAL AI - PROGRAM] Error:", error.message);
    
    // Handle specific error codes
    if (error.message.includes("401") || error.message.includes("unauthorized")) {
      return res.status(401).json({ 
        message: "Invalid Mistral API key" 
      });
    }
    
    if (error.message.includes("429") || error.message.includes("rate limit")) {
      return res.status(429).json({ 
        message: "Rate limit exceeded. Please try again later." 
      });
    }

    if (error.message === "Request timeout") {
      return res.status(504).json({ 
        message: "Request timeout. Please try again." 
      });
    }

    return res.status(500).json({ 
      message: "Error generating training program",
      error: error.message 
    });
  }
});

/**
 * POST /api/ai/mycoach
 * Chat conversationnel with AI coach
 * Body: { message, conversationHistory? }
 */
router.post("/api/ai/chat", authenticateToken, async (req, res) => {
  try {
    const { message, conversationHistory = [] } = req.body;

    // Validation
    if (!message || message.trim().length === 0) {
      return res.status(400).json({ 
        message: "message is required" 
      });
    }

    // Sanitize and limit message length
    const sanitizedMessage = message.trim().substring(0, 1000);

    // Get user data for personalization
    const user = getUserById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Calculate user statistics
    const runningData = user.runningData;
    const totalDistance = runningData.reduce(
      (sum, session) => sum + session.distance,
      0
    ).toFixed(1);
    const totalSessions = runningData.length;
    const avgDistance = (totalDistance / totalSessions).toFixed(1);

    // Build system prompt for the coach
    const systemPrompt = `Tu es un coach sportif personnel bienveillant et professionnel, spécialisé en course à pied et fitness.

Profil de l'utilisateur:
- Nom: ${user.userInfos.firstName} ${user.userInfos.lastName}
- Âge: ${user.userInfos.age} ans
- Poids: ${user.userInfos.weight} kg
- Taille: ${user.userInfos.height} cm
- Distance totale parcourue: ${totalDistance} km
- Nombre de sessions: ${totalSessions}
- Distance moyenne par session: ${avgDistance} km

Tes responsabilités:
- Répondre aux questions sur l'entraînement, la nutrition, la récupération
- Donner des conseils personnalisés basés sur le profil de l'utilisateur
- Être encourageant et motivant
- Être concis (maximum 3-4 phrases par réponse)
- Utiliser un ton amical et professionnel

Si l'utilisateur demande quelque chose qui n'est pas lié au sport/fitness, redirige-le vers des questions sportives.`;

    // Build messages array for Mistral
    const messages = [
      {
        role: "system",
        content: systemPrompt
      }
    ];

    // Add conversation history (limit to last 10 messages to avoid token limits)
    const recentHistory = conversationHistory.slice(-10);
    messages.push(...recentHistory);

    // Add current user message
    messages.push({
      role: "user",
      content: sanitizedMessage
    });

    console.log("[MISTRAL AI - MYCOACH] Sending request to Mistral AI...");
    
    // Call Mistral API with timeout
    const chatResponse = await Promise.race([
      mistralClient.chat.complete({
        model: "mistral-small-latest",
        messages: messages,
        temperature: 0.8,
        maxTokens: 500, // Keep responses concise
      }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Request timeout")), 20000)
      )
    ]);

    if (!chatResponse.choices || chatResponse.choices.length === 0) {
      throw new Error("No response from Mistral AI");
    }

    const assistantMessage = chatResponse.choices[0].message.content;
    console.log("[MISTRAL AI - MYCOACH] Response received successfully");

    return res.json({
      success: true,
      message: assistantMessage,
      timestamp: new Date().toISOString(),
      metadata: {
        userId: user.id,
        model: "mistral-small-latest"
      }
    });

  } catch (error) {
    console.error("[MISTRAL AI - MYCOACH] Error:", error.message);
    
    // Handle specific error codes
    if (error.message.includes("401") || error.message.includes("unauthorized")) {
      return res.status(401).json({ 
        message: "Invalid Mistral API key" 
      });
    }
    
    if (error.message.includes("429") || error.message.includes("rate limit")) {
      return res.status(429).json({ 
        message: "Rate limit exceeded. Please try again later." 
      });
    }

    if (error.message === "Request timeout") {
      return res.status(504).json({ 
        message: "Request timeout. Please try again." 
      });
    }

    return res.status(500).json({ 
      message: "Error communicating with AI coach",
      error: error.message 
    });
  }
});

/**
 * GET /api/ai/health
 * Check if Mistral AI service is available
 */
router.get("/api/ai/health", (req, res) => {
  const isConfigured = !!process.env.MISTRAL_API_KEY;
  
  return res.json({
    status: isConfigured ? "configured" : "not configured",
    service: "Mistral AI",
    model: "mistral-small-latest",
    endpoints: {
      program: "/api/ai/program",
      mycoach: "/api/ai/mycoach"
    }
  });
});

module.exports = router;