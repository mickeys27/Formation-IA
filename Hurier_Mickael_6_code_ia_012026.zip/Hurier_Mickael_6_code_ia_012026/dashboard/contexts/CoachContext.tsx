// contexts/CoachContext.tsx
'use client';

import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { ChatMessage, TrainingProgram } from '../src/types/coach.types';

export interface ConversationSummary {
  id: string;
  firstMessage: string;
  lastMessage: string;
  timestamp: string;
  messageCount: number;
  messages: ChatMessage[]; 
}

interface CoachContextType {
  // Chat state
  isCoachModalOpen: boolean;
  chatMessages: ChatMessage[];
  isChatLoading: boolean;
  chatError: string | null;
  
  // Program state
  currentProgram: TrainingProgram | null;
  isProgramLoading: boolean;
  programError: string | null;
  
  // Conversation history
  conversationHistory: ConversationSummary[];
  
  // Chat actions
  openCoachModal: () => void;
  closeCoachModal: () => void;
  addMessage: (message: ChatMessage) => void;
  setChatLoading: (loading: boolean) => void;
  setChatError: (error: string | null) => void;
  clearChat: () => void;
  
  // Program actions
  setCurrentProgram: (program: TrainingProgram | null) => void;
  setProgramLoading: (loading: boolean) => void;
  setProgramError: (error: string | null) => void;
  
  // History actions
  saveCurrentConversation: () => void;
  loadConversation: (conversationId: string) => void;
  clearAllHistory: () => void; // ✅ NOUVEAU : pour supprimer à la déconnexion
}

const CoachContext = createContext<CoachContextType | undefined>(undefined);

interface CoachProviderProps {
  children: ReactNode;
}

const MAX_CONVERSATIONS = 3;
const STORAGE_KEY = 'sportsee_coach_history';

// ✅ Fonction pour charger l'historique depuis localStorage
const loadHistoryFromStorage = (): ConversationSummary[] => {
  if (typeof window === 'undefined') return [];
  
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    
    const parsed = JSON.parse(stored);
    console.log('📥 Historique chargé depuis localStorage:', parsed.length, 'conversations');
    return parsed;
  } catch (error) {
    console.error('❌ Erreur chargement historique:', error);
    return [];
  }
};

// ✅ Fonction pour sauvegarder l'historique dans localStorage
const saveHistoryToStorage = (history: ConversationSummary[]) => {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    console.log('💾 Historique sauvegardé dans localStorage:', history.length, 'conversations');
  } catch (error) {
    console.error('❌ Erreur sauvegarde historique:', error);
  }
};

// ✅ Fonction pour supprimer l'historique du localStorage
const clearHistoryFromStorage = () => {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.removeItem(STORAGE_KEY);
    console.log('🧹 Historique supprimé du localStorage');
  } catch (error) {
    console.error('❌ Erreur suppression historique:', error);
  }
};

export const CoachProvider: React.FC<CoachProviderProps> = ({ children }) => {
  // Chat state
  const [isCoachModalOpen, setIsCoachModalOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  
  // Program state
  const [currentProgram, setCurrentProgram] = useState<TrainingProgram | null>(null);
  const [isProgramLoading, setIsProgramLoading] = useState(false);
  const [programError, setProgramError] = useState<string | null>(null);
  
  // ✅ Conversation history avec chargement depuis localStorage
  const [conversationHistory, setConversationHistory] = useState<ConversationSummary[]>([]);
  const [isHistoryLoaded, setIsHistoryLoaded] = useState(false);

  // ✅ Charger l'historique au montage du composant (une seule fois)
  useEffect(() => {
    const history = loadHistoryFromStorage();
    setConversationHistory(history);
    setIsHistoryLoaded(true);
  }, []);

  // ✅ Sauvegarder l'historique à chaque modification
  useEffect(() => {
    // Éviter de sauvegarder avant le premier chargement
    if (!isHistoryLoaded) return;
    
    saveHistoryToStorage(conversationHistory);
  }, [conversationHistory, isHistoryLoaded]);

  // Chat actions
  const openCoachModal = () => setIsCoachModalOpen(true);
  const closeCoachModal = () => setIsCoachModalOpen(false);
  
  const addMessage = (message: ChatMessage) => {
    setChatMessages(prev => [...prev, message]);
  };
  
  const setChatLoading = (loading: boolean) => {
    setIsChatLoading(loading);
  };
  
  const clearChat = () => {
    setChatMessages([]);
    setChatError(null);
  };

  // Program actions
  const setProgramLoading = (loading: boolean) => {
    setIsProgramLoading(loading);
  };

  // ✅ Sauvegarder la conversation actuelle
  const saveCurrentConversation = () => {
    if (chatMessages.length < 2) {
      console.log('⚠️ Pas assez de messages pour sauvegarder');
      return;
    }

    const userMessages = chatMessages.filter(m => m.role === 'user');
    const assistantMessages = chatMessages.filter(m => m.role === 'assistant');
    
    if (userMessages.length === 0 || assistantMessages.length === 0) {
      console.log('⚠️ Pas de conversation valide (manque user ou assistant)');
      return;
    }

    const firstMessage = userMessages[0].content;
    const lastMessage = assistantMessages[assistantMessages.length - 1].content;
    
    const newConversation: ConversationSummary = {
      id: Date.now().toString(),
      firstMessage: firstMessage.substring(0, 60),
      lastMessage: lastMessage.substring(0, 60),
      timestamp: new Date().toISOString(),
      messageCount: chatMessages.length,
      messages: [...chatMessages], // ✅ Sauvegarder tous les messages
    };
    
    // ✅ Ajouter au début et garder seulement les 3 dernières
    setConversationHistory(prev => {
      const updated = [newConversation, ...prev].slice(0, MAX_CONVERSATIONS);
      console.log('💾 Conversation sauvegardée:', {
        id: newConversation.id,
        messageCount: newConversation.messageCount,
        totalConversations: updated.length,
      });
      return updated;
    });
  };

  // ✅ Charger une conversation depuis l'historique
  const loadConversation = (conversationId: string) => {
    console.log('🔍 Recherche de la conversation:', conversationId);
    
    const conversation = conversationHistory.find(conv => conv.id === conversationId);
    
    if (!conversation) {
      console.error('❌ Conversation non trouvée:', conversationId);
      console.log('🔑 IDs disponibles:', conversationHistory.map(c => c.id));
      return;
    }

    console.log('✅ Conversation trouvée:', {
      id: conversation.id,
      messageCount: conversation.messageCount,
      messagesLength: conversation.messages.length,
    });
    
    // ✅ Vider le chat actuel
    clearChat();
    
    // ✅ Recharger tous les messages de la conversation
    setChatMessages([...conversation.messages]);
    
    console.log('✅ Conversation chargée avec succès');
  };

  // ✅ NOUVEAU : Supprimer tout l'historique (appelé à la déconnexion)
  const clearAllHistory = () => {
    console.log('🧹 Suppression de tout l\'historique...');
    setConversationHistory([]);
    clearHistoryFromStorage();
    clearChat();
    console.log('✅ Historique supprimé');
  };

  const value: CoachContextType = {
    isCoachModalOpen,
    chatMessages,
    isChatLoading,
    chatError,
    currentProgram,
    isProgramLoading,
    programError,
    conversationHistory,
    openCoachModal,
    closeCoachModal,
    addMessage,
    setChatLoading,
    setChatError,
    clearChat,
    setCurrentProgram,
    setProgramLoading,
    setProgramError,
    saveCurrentConversation,
    loadConversation,
    clearAllHistory, // ✅ NOUVEAU
  };

  return (
    <CoachContext.Provider value={value}>
      {children}
    </CoachContext.Provider>
  );
};

export const useCoach = (): CoachContextType => {
  const context = useContext(CoachContext);
  if (context === undefined) {
    throw new Error('useCoach must be used within a CoachProvider');
  }
  return context;
};