// src/mocks/trainingPlan.mock.ts

import { ProgramResponse } from '@/src/types/coach.types';

/**
 * MOCK TrainingPlan
 * Basé sur POST http://localhost:8000/api/ai/training-plan
 */

/**
 * Programme mock 1 : Endurance
 */
export const mockEnduranceProgram: ProgramResponse = {
  success: true,
  program: {
    objective: "Améliorer l'endurance en augmentant progressivement la distance et la durée des séances de course à pied",
    startDate: "2025-02-01",
    duration: "6 semaines",
    weeks: [
      {
        weekNumber: 1,
        weekTitle: "Semaine de base et adaptation",
        sessions: [
          {
            day: "Lundi",
            title: "Course continue modérée",
            description: "Course à allure modérée sans interruption pour travailler l'endurance de base",
            duration: 30,
            intensity: "modérée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Mercredi",
            title: "Fartlek (jeu de vitesse)",
            description: "Alternance de 1 minute de course rapide et 2 minutes de course lente pendant 30 minutes",
            duration: 30,
            intensity: "variable",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Vendredi",
            title: "Renforcement musculaire",
            description: "Séance de renforcement des jambes (squats, fentes, step-ups) et gainage",
            duration: 30,
            intensity: "modérée",
            targetMuscles: "jambes, gainage"
          }
        ]
      },
      {
        weekNumber: 2,
        weekTitle: "Augmentation progressive de l'intensité",
        sessions: [
          {
            day: "Lundi",
            title: "Course continue modérée",
            description: "Course à allure modérée sans interruption pour consolider l'endurance",
            duration: 35,
            intensity: "modérée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Mercredi",
            title: "Fartlek (jeu de vitesse)",
            description: "Alternance de 1 minute 30 de course rapide et 2 minutes de course lente pendant 35 minutes",
            duration: 35,
            intensity: "variable",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Vendredi",
            title: "Renforcement musculaire",
            description: "Séance de renforcement des jambes (squats, fentes, step-ups) et gainage",
            duration: 35,
            intensity: "modérée",
            targetMuscles: "jambes, gainage"
          }
        ]
      },
      {
        weekNumber: 3,
        weekTitle: "Introduction des intervalles longs",
        sessions: [
          {
            day: "Lundi",
            title: "Course continue modérée",
            description: "Course à allure modérée sans interruption pour consolider l'endurance",
            duration: 40,
            intensity: "modérée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Mercredi",
            title: "Intervalles longs",
            description: "Alternance de 3 minutes de course rapide et 2 minutes de course lente pendant 40 minutes",
            duration: 40,
            intensity: "élevée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Vendredi",
            title: "Renforcement musculaire",
            description: "Séance de renforcement des jambes (squats, fentes, step-ups) et gainage",
            duration: 40,
            intensity: "modérée",
            targetMuscles: "jambes, gainage"
          }
        ]
      },
      {
        weekNumber: 4,
        weekTitle: "Augmentation de la durée des intervalles",
        sessions: [
          {
            day: "Lundi",
            title: "Course continue modérée",
            description: "Course à allure modérée sans interruption pour consolider l'endurance",
            duration: 45,
            intensity: "modérée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Mercredi",
            title: "Intervalles longs",
            description: "Alternance de 4 minutes de course rapide et 2 minutes de course lente pendant 45 minutes",
            duration: 45,
            intensity: "élevée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Vendredi",
            title: "Renforcement musculaire",
            description: "Séance de renforcement des jambes (squats, fentes, step-ups) et gainage",
            duration: 45,
            intensity: "modérée",
            targetMuscles: "jambes, gainage"
          }
        ]
      },
      {
        weekNumber: 5,
        weekTitle: "Optimisation de l'endurance",
        sessions: [
          {
            day: "Lundi",
            title: "Course continue modérée",
            description: "Course à allure modérée sans interruption pour consolider l'endurance",
            duration: 50,
            intensity: "modérée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Mercredi",
            title: "Intervalles longs",
            description: "Alternance de 5 minutes de course rapide et 2 minutes de course lente pendant 50 minutes",
            duration: 50,
            intensity: "élevée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Vendredi",
            title: "Renforcement musculaire",
            description: "Séance de renforcement des jambes (squats, fentes, step-ups) et gainage",
            duration: 50,
            intensity: "modérée",
            targetMuscles: "jambes, gainage"
          }
        ]
      },
      {
        weekNumber: 6,
        weekTitle: "Test d'endurance et consolidation",
        sessions: [
          {
            day: "Lundi",
            title: "Course continue modérée",
            description: "Course à allure modérée sans interruption pour tester l'endurance",
            duration: 55,
            intensity: "modérée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Mercredi",
            title: "Intervalles longs",
            description: "Alternance de 5 minutes de course rapide et 2 minutes de course lente pendant 55 minutes",
            duration: 55,
            intensity: "élevée",
            targetMuscles: "jambes, cardio"
          },
          {
            day: "Vendredi",
            title: "Renforcement musculaire",
            description: "Séance de renforcement des jambes (squats, fentes, step-ups) et gainage",
            duration: 55,
            intensity: "modérée",
            targetMuscles: "jambes, gainage"
          }
        ]
      }
    ],
    recommendations: [
      "Écoutez votre corps et ajustez l'intensité si nécessaire pour éviter les blessures.",
      "Hydratez-vous bien avant, pendant et après chaque séance.",
      "Étirez-vous après chaque séance pour améliorer la récupération musculaire."
    ]
  },
  metadata: {
    generatedAt: new Date().toISOString(),
    userId: 11,
    model: "mock-data"
  }
};

/**
 * Programme mock 2 : Préparation 10km
 */
export const mock10kProgram: ProgramResponse = {
  success: true,
  program: {
    objective: "Préparer un 10km avec une progression adaptée sur 6 semaines",
    startDate: "2025-02-01",
    duration: "6 semaines",
    weeks: [
      {
        weekNumber: 1,
        weekTitle: "Base aérobie",
        sessions: [
          {
            day: "Lundi",
            title: "Endurance fondamentale",
            description: "30 minutes de course à allure conversationnelle pour développer la base aérobie",
            duration: 30,
            intensity: "légère",
            targetMuscles: "cardio, jambes"
          },
          {
            day: "Mercredi",
            title: "Fractionné court",
            description: "8 x 400m à allure 10km avec 90 secondes de récupération entre chaque répétition",
            duration: 40,
            intensity: "élevée",
            targetMuscles: "VMA, jambes"
          },
          {
            day: "Dimanche",
            title: "Sortie longue",
            description: "45 minutes de course à allure facile pour développer l'endurance",
            duration: 45,
            intensity: "légère",
            targetMuscles: "endurance"
          }
        ]
      },
      {
        weekNumber: 2,
        weekTitle: "Développement VMA",
        sessions: [
          {
            day: "Lundi",
            title: "Tempo run",
            description: "20 minutes à allure seuil (85% FCM) pour développer le seuil lactique",
            duration: 35,
            intensity: "élevée",
            targetMuscles: "seuil, cardio"
          },
          {
            day: "Mercredi",
            title: "Fractionné pyramidal",
            description: "400m - 800m - 1200m - 800m - 400m à 90% VMA avec récupération égale",
            duration: 45,
            intensity: "intense",
            targetMuscles: "VMA, résistance"
          },
          {
            day: "Dimanche",
            title: "Endurance longue",
            description: "50 minutes de course continue facile pour consolider l'endurance",
            duration: 50,
            intensity: "légère",
            targetMuscles: "endurance"
          }
        ]
      },
      {
        weekNumber: 3,
        weekTitle: "Allure spécifique",
        sessions: [
          {
            day: "Lundi",
            title: "Allure 10km",
            description: "2 x 12 minutes à allure 10km cible avec 3 minutes de récupération",
            duration: 40,
            intensity: "élevée",
            targetMuscles: "allure course"
          },
          {
            day: "Mercredi",
            title: "Côtes courtes",
            description: "10 x 1 minute en côte à 95% effort avec descente en récupération",
            duration: 35,
            intensity: "intense",
            targetMuscles: "puissance, VMA"
          },
          {
            day: "Dimanche",
            title: "Sortie longue progressive",
            description: "55 minutes avec 15 dernières minutes à allure 10km",
            duration: 55,
            intensity: "modérée",
            targetMuscles: "endurance, allure"
          }
        ]
      },
      {
        weekNumber: 4,
        weekTitle: "Volume et intensité",
        sessions: [
          {
            day: "Lundi",
            title: "Fartlek",
            description: "40 minutes avec variations d'allure (1-2-3 minutes rapide/lent)",
            duration: 40,
            intensity: "modérée",
            targetMuscles: "polyvalence"
          },
          {
            day: "Mercredi",
            title: "Fractionné 1km",
            description: "5 x 1000m à allure 10km avec 2 minutes de récupération",
            duration: 45,
            intensity: "élevée",
            targetMuscles: "allure course"
          },
          {
            day: "Dimanche",
            title: "Sortie longue",
            description: "60 minutes avec progression graduelle",
            duration: 60,
            intensity: "modérée",
            targetMuscles: "endurance"
          }
        ]
      },
      {
        weekNumber: 5,
        weekTitle: "Affûtage",
        sessions: [
          {
            day: "Lundi",
            title: "Simulation 8km",
            description: "8km à allure 10km visée - test grandeur nature",
            duration: 50,
            intensity: "élevée",
            targetMuscles: "simulation"
          },
          {
            day: "Mercredi",
            title: "Vitesse pure",
            description: "6 x 300m très rapide avec 2 minutes de récupération",
            duration: 35,
            intensity: "intense",
            targetMuscles: "vitesse"
          },
          {
            day: "Dimanche",
            title: "Récupération active",
            description: "40 minutes très facile pour récupérer avant la dernière semaine",
            duration: 40,
            intensity: "légère",
            targetMuscles: "récupération"
          }
        ]
      },
      {
        weekNumber: 6,
        weekTitle: "Semaine de course",
        sessions: [
          {
            day: "Lundi",
            title: "Activation légère",
            description: "25 minutes facile + 5 x 100m en accélération progressive",
            duration: 30,
            intensity: "légère",
            targetMuscles: "activation"
          },
          {
            day: "Mercredi",
            title: "Repos actif",
            description: "15 minutes de jogging très léger ou repos complet selon ressenti",
            duration: 15,
            intensity: "très légère",
            targetMuscles: "récupération"
          },
          {
            day: "Dimanche",
            title: "COURSE 10KM",
            description: "Votre objectif ! Échauffement 15 min puis donnez tout",
            duration: 70,
            intensity: "compétition",
            targetMuscles: "performance"
          }
        ]
      }
    ],
    recommendations: [
      "Ne négligez pas l'échauffement : 10-15 minutes avant chaque séance intensive.",
      "Testez votre équipement et nutrition pendant l'entraînement, pas le jour J.",
      "La récupération fait partie de l'entraînement : dormez suffisamment."
    ]
  },
  metadata: {
    generatedAt: new Date().toISOString(),
    userId: 12,
    model: "mock-data"
  }
};

/**
 * Fonction pour récupérer un programme aléatoire (simule l'API)
 */
export const getTrainingProgram = async (): Promise<ProgramResponse> => {
  // Simulation d'un délai réseau (1.5 secondes)
  console.log('🎭 Mode MOCK : Génération du programme...');
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Alterner entre les 2 programmes
  const programs = [mockEnduranceProgram, mock10kProgram];
  const randomIndex = Math.floor(Math.random() * programs.length);
  const selectedProgram = programs[randomIndex];
  
  console.log('✅ Programme mock généré:', selectedProgram.program.objective);
  
  return selectedProgram;
};