/**
 * Ce fichier permet d'importer facilement tous les mocks
 * depuis un seul endroit
 */

// Export des types
export type {
  LoginRequest,
  LoginResponse
} from './login.mock';

export type {
  UserProfile,
  UserStatistics,
  UserInfoResponse
} from './user-info.mock';

export type {
  HeartRate,
  ActivitySession,
  UserActivityResponse
} from './user-activity.mock';

// Export des fonctions mock
export { mockLogin } from './login.mock';
export { getUserInfo, mockUserInfo } from './user-info.mock';
export { getUserActivity, mockUserActivity } from './user-activity.mock';

/**
 * 💡 UTILISATION :
 * 
 * // Au lieu de faire plusieurs imports :
 * import { mockLogin } from '@/mocks/api/login.mock';
 * import { getUserInfo } from '@/mocks/api/user-info.mock';
 * 
 * // Vous pouvez tout importer depuis un seul fichier :
 * import { mockLogin, getUserInfo, getUserActivity } from '@/mocks/api';
 */