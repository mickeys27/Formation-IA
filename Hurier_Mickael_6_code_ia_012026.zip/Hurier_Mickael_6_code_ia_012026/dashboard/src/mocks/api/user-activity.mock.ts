/**
 * 📊 MOCK UserActivity
 * Basé sur GET http://localhost:8000/api/user-activity
 * Params: startWeek=2025-01-01&endWeek=2025-01-31
 */

export interface HeartRate {
  min: number;
  max: number;
  average: number;
}

export interface ActivitySession {
  date: string;
  distance: number;        // en km
  duration: number;        // en minutes
  heartRate: HeartRate;
  caloriesBurned: number;
}

export type UserActivityResponse = ActivitySession[];

/**
 * Données mockées correspondant à la réponse de l'API
 * Basé sur les données de l'image 2
 */
export const mockUserActivity: UserActivityResponse = [
  {
    date: "2025-01-04",
    distance: 5.8,
    duration: 38,
    heartRate: {
      min: 140,
      max: 178,
      average: 163
    },
    caloriesBurned: 422
  },
  {
    date: "2025-01-05",
    distance: 3.2,
    duration: 20,
    heartRate: {
      min: 148,
      max: 184,
      average: 171
    },
    caloriesBurned: 248
  },
  {
    date: "2025-01-09",
    distance: 6.4,
    duration: 42,
    heartRate: {
      min: 140,
      max: 176,
      average: 163
    },
    caloriesBurned: 510
  },
  {
    date: "2025-01-12",
    distance: 7.2,
    duration: 45,
    heartRate: {
      min: 135,
      max: 180,
      average: 158
    },
    caloriesBurned: 580
  },
  {
    date: "2025-01-15",
    distance: 4.5,
    duration: 28,
    heartRate: {
      min: 142,
      max: 175,
      average: 165
    },
    caloriesBurned: 340
  },
  {
    date: "2025-01-18",
    distance: 8.1,
    duration: 52,
    heartRate: {
      min: 138,
      max: 182,
      average: 160
    },
    caloriesBurned: 620
  },
  {
    date: "2025-01-21",
    distance: 5.2,
    duration: 35,
    heartRate: {
      min: 145,
      max: 179,
      average: 167
    },
    caloriesBurned: 410
  },
  {
    date: "2025-01-24",
    distance: 6.8,
    duration: 44,
    heartRate: {
      min: 140,
      max: 177,
      average: 162
    },
    caloriesBurned: 530
  },
  {
    date: "2025-01-27",
    distance: 3.9,
    duration: 25,
    heartRate: {
      min: 150,
      max: 185,
      average: 170
    },
    caloriesBurned: 305
  },
  {
    date: "2025-01-30",
    distance: 7.5,
    duration: 48,
    heartRate: {
      min: 137,
      max: 181,
      average: 159
    },
    caloriesBurned: 590
  }
];

/**
 * Fonction pour récupérer l'activité utilisateur (simule l'API)
 * @param startWeek - Date de début (format: YYYY-MM-DD)
 * @param endWeek - Date de fin (format: YYYY-MM-DD)
 */
export const getUserActivity = async (
  startWeek?: string,
  endWeek?: string
): Promise<UserActivityResponse> => {
  // Simulation d'un délai réseau
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Si des dates sont fournies, on pourrait filtrer les données
  // Pour l'instant, on retourne toutes les données
  return mockUserActivity;
};