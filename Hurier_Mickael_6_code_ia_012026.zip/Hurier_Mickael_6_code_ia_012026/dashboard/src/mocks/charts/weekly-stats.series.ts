// src/mocks/charts/weekly-stats.series.ts
import { userActivitySeries } from "./user-activity.series";

export type WeeklyStats = {
  week: string;
  totalKm: number;
  avgHeartRate: number;
  sessions: number;
  totalCalories: number;
};

/**
 * Regroupe les activités par semaine
 */
const calculateWeeklyStats = (): WeeklyStats[] => {
  const weeklyMap = new Map<number, {
    totalKm: number;
    totalHR: number;
    sessions: number;
    totalCalories: number;
  }>();

  // Parcourir toutes les activités
  userActivitySeries.forEach((activity) => {
    const date = new Date(activity.date);
    const weekNumber = Math.ceil(date.getDate() / 7);
    
    const current = weeklyMap.get(weekNumber) || {
      totalKm: 0,
      totalHR: 0,
      sessions: 0,
      totalCalories: 0
    };
    
    weeklyMap.set(weekNumber, {
      totalKm: current.totalKm + activity.distanceKm,
      totalHR: current.totalHR + activity.hrAvg,
      sessions: current.sessions + 1,
      totalCalories: current.totalCalories + activity.calories
    });
  });

  const result: WeeklyStats[] = [];
  
  weeklyMap.forEach((data, weekNum) => {
    result.push({
      week: `S${weekNum}`,
      totalKm: Math.round(data.totalKm * 10) / 10,
      avgHeartRate: Math.round(data.totalHR / data.sessions),
      sessions: data.sessions,
      totalCalories: data.totalCalories
    });
  });

  return result.sort((a, b) => 
    parseInt(a.week.slice(1)) - parseInt(b.week.slice(1))
  );
};

// Export des données
export const weeklyStatsSeries = calculateWeeklyStats();

// Export de la fonction
export const getAverageWeeklyDistance = (): number => {
  const total = weeklyStatsSeries.reduce((sum, week) => sum + week.totalKm, 0);
  return Math.round(total / weeklyStatsSeries.length);
};