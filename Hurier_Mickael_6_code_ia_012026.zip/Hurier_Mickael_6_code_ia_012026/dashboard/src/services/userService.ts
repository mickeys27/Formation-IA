// src/services/userService.ts
import { DATA_SOURCE, apiFetch } from './apiClient';
import { getUserInfo } from '@/src/mocks/api/user-info.mock';
import { getUserActivity } from '@/src/mocks/api/user-activity.mock';

import type { UserInfoResponse } from '@/src/mocks/api/user-info.mock';
import type { UserActivityResponse } from '@/src/mocks/api/user-activity.mock';

export async function fetchUserInfo(): Promise<UserInfoResponse> {
  console.log('📊 fetchUserInfo - Mode:', DATA_SOURCE);
  
  if (DATA_SOURCE === 'mock') {
    return getUserInfo();
  }
  
  return apiFetch<UserInfoResponse>('/api/user-info');
}

export async function fetchUserActivity(
  startWeek?: string,
  endWeek?: string
): Promise<UserActivityResponse> {
  console.log('📊 fetchUserActivity - Mode:', DATA_SOURCE, { startWeek, endWeek });
  
  if (DATA_SOURCE === 'mock') {
    return getUserActivity();
  }
  
  const params = new URLSearchParams();
  if (startWeek) params.append('startWeek', startWeek);
  if (endWeek) params.append('endWeek', endWeek);
  
  const endpoint = `/api/user-activity?${params.toString()}`;
  console.log('🌐 Fetching:', endpoint);
  
  return apiFetch<UserActivityResponse>(endpoint);
}