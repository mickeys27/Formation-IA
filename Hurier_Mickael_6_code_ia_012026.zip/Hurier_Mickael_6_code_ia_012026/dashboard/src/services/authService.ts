import { DATA_SOURCE, apiFetch } from './apiClient';
import type { LoginRequest, LoginResponse } from '@/src/mocks/api/login.mock';
import { mockLogin } from '@/src/mocks/api/login.mock';

export async function login(credentials: LoginRequest): Promise<LoginResponse> {
  if (DATA_SOURCE === 'mock') {
    return mockLogin(credentials);
  }

  // Ajuste si ton backend attend email au lieu de username
  return apiFetch<LoginResponse>('/api/login', {
    method: 'POST',
    body: JSON.stringify(credentials),
  });
}
