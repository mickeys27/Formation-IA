// src/services/aiService.ts

import {
  ProgramRequest,
  ProgramResponse,
  CoachChatRequest,
  CoachChatResponse,
} from '../types/coach.types';
import { getTrainingProgram } from '../mocks/api/training-plan.mock';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';

// ✅ Variable d'environnement pour activer le mode mock
const USE_MOCK = process.env.NEXT_PUBLIC_USE_MOCK === 'true';

export class AIServiceError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: any
  ) {
    super(message);
    this.name = 'AIServiceError';
  }
}

function getAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('token');
}

class AIService {
  private async fetchWithAuth(url: string, options: RequestInit = {}) {
    const token = getAuthToken();
    
    if (!token) {
      throw new AIServiceError('Authentication required. Please login.', 401);
    }

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options.headers,
    };

    console.log('🤖 AI API Request:', {
      method: options.method || 'POST',
      url,
      hasToken: !!token,
      mockMode: USE_MOCK
    });

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Unknown error' }));
        
        if (response.status === 401) {
          console.error('🔐 AI API: Session expired');
          if (typeof window !== 'undefined') {
            localStorage.removeItem('user');
            localStorage.removeItem('token');
            window.location.href = '/login';
          }
          throw new AIServiceError('Session expired. Please login again.', 401, error);
        }
        
        if (response.status === 429) {
          throw new AIServiceError('Too many requests. Please try again later.', 429, error);
        }
        
        if (response.status === 504) {
          throw new AIServiceError('Request timeout. Please try again.', 504, error);
        }
        
        throw new AIServiceError(
          error.message || `HTTP Error ${response.status}`,
          response.status,
          error
        );
      }

      const data = await response.json();
      console.log('✅ AI API Response:', data);
      return data;
    } catch (error) {
      if (error instanceof AIServiceError) {
        throw error;
      }

      console.error('❌ AI API Network Error:', error);
      throw new AIServiceError(
        'Erreur de connexion au serveur AI',
        0,
        { originalError: error }
      );
    }
  }

  /**
   * Generate a 6-week training program
   * ✅ Supporte le mode mock avec NEXT_PUBLIC_USE_MOCK=true
   */
  async generateProgram(request: ProgramRequest): Promise<ProgramResponse> {
    // ✅ MODE MOCK : Retourner des données de test
    if (USE_MOCK) {
      console.log('🎭 Mode MOCK activé pour generateProgram');
      console.log('📝 Paramètres ignorés (mode mock):', request);
      return getTrainingProgram();
    }

    // MODE NORMAL : Appel API
    return this.fetchWithAuth(`${API_BASE_URL}/api/ai/training-plan`, {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  /**
   * Chat with AI coach
   */
  async chatWithCoach(request: CoachChatRequest): Promise<CoachChatResponse> {
    return this.fetchWithAuth(`${API_BASE_URL}/api/ai/chat`, {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  /**
   * Check AI service health
   */
  async checkHealth() {
    const response = await fetch(`${API_BASE_URL}/api/ai/health`);
    return response.json();
  }
}

export const aiService = new AIService();