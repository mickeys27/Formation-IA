// src/services/apiClient.ts

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';

export const DATA_SOURCE = process.env.NEXT_PUBLIC_USE_MOCK === 'true' ? 'mock' : 'api';

console.log('🔧 API Client Config:', {
  API_BASE_URL,
  DATA_SOURCE,
  USE_MOCK: process.env.NEXT_PUBLIC_USE_MOCK
});

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

function getAuthToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('token');
}

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  private async request<T>(
    endpoint: string,
    options?: RequestInit
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    const token = getAuthToken();

    console.log('🌐 API Request:', {
      method: options?.method || 'GET',
      url,
      hasToken: !!token
    });

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...(token && { 'Authorization': `Bearer ${token}` }),
          ...options?.headers,
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        
        if (response.status === 401) {
          console.error('🔐 Erreur 401: Non authentifié');
          if (typeof window !== 'undefined') {
            localStorage.removeItem('user');
            localStorage.removeItem('token');
            window.location.href = '/login';
          }
        }
        
        throw new ApiError(
          errorData?.message || `HTTP Error ${response.status}`,
          response.status,
          errorData
        );
      }

      const data = await response.json();
      console.log('✅ API Response:', data);
      return data;
    } catch (error) {
      if (error instanceof ApiError) {
        throw error;
      }

      console.error('❌ Network Error:', error);
      throw new ApiError(
        'Erreur de connexion au serveur',
        0,
        { originalError: error }
      );
    }
  }

  async get<T>(endpoint: string, params?: Record<string, string>): Promise<T> {
    const hasParams = endpoint.includes('?');
    const queryString = params && !hasParams
      ? '?' + new URLSearchParams(params).toString()
      : '';
    
    return this.request<T>(`${endpoint}${queryString}`, {
      method: 'GET',
    });
  }

  async post<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }
}

export const apiClient = new ApiClient(API_BASE_URL);

export async function apiFetch<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  if (options?.method === 'POST') {
    return apiClient.post<T>(endpoint, options.body ? JSON.parse(options.body as string) : undefined);
  }
  return apiClient.get<T>(endpoint);
}