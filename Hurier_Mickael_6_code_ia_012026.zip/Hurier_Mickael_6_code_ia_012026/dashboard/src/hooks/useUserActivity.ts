// src/hooks/useUserActivity.ts
'use client';

import { useState, useEffect } from 'react';
import { fetchUserActivity } from '@/src/services/userService';
import { UserActivityResponse } from '@/src/mocks/api/user-activity.mock';

interface UseUserActivityParams {
  startWeek?: string;
  endWeek?: string;
}

interface UseUserActivityResult {
  data: UserActivityResponse | null;
  loading: boolean;
  error: string | null;
  refetch: (params?: UseUserActivityParams) => void;
}

export function useUserActivity(
  params?: UseUserActivityParams
): UseUserActivityResult {
  const [data, setData] = useState<UserActivityResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async (fetchParams?: UseUserActivityParams) => {
    try {
      setLoading(true);
      setError(null);

      const queryParams = fetchParams || params;
      
      const response = await fetchUserActivity(
        queryParams?.startWeek,
        queryParams?.endWeek
      );
      
      setData(response);
    } catch (err: any) {
      setError(err.message || 'Une erreur est survenue lors du chargement des activités');
      console.error('❌ Erreur useUserActivity:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [params?.startWeek, params?.endWeek]);

  return {
    data,
    loading,
    error,
    refetch: fetchData,
  };
}