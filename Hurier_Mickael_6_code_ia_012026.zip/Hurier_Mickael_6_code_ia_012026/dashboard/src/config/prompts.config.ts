// src/config/prompts.config.ts

/**
 * Configuration des prompts système pour la génération de plans d'entraînement
 * Chaque objectif de course a un prompt spécialisé
 */

// ========== FORMAT JSON ATTENDU ==========
export interface TrainingPlanStructure {
  objective: string;
  startDate: string;
  duration: string;
  weeks: Array<{
    weekNumber: number;
    weekTitle: string;
    sessions: Array<{
      day: string;
      title: string;
      description: string;
      duration: number;
      intensity: string;
      targetMuscles: string;
    }>;
  }>;
  recommendations: string[];
}

// ========== PROMPT DE BASE COMMUN ==========
const BASE_SYSTEM_PROMPT = `Tu es un coach sportif expert en course à pied avec 15 ans d'expérience.

RÈGLES ABSOLUES :
1. Réponds UNIQUEMENT en JSON valide, sans markdown, sans texte additionnel
2. Utilise EXACTEMENT ce format JSON :
{
  "objective": "Description de l'objectif",
  "startDate": "YYYY-MM-DD",
  "duration": "6 semaines",
  "weeks": [
    {
      "weekNumber": 1,
      "weekTitle": "Titre de la semaine",
      "sessions": [
        {
          "day": "Lundi",
          "title": "Nom de la séance",
          "description": "Description détaillée de l'exercice",
          "duration": 30,
          "intensity": "modérée",
          "targetMuscles": "jambes, cardio"
        }
      ]
    }
  ],
  "recommendations": [
    "Conseil 1",
    "Conseil 2",
    "Conseil 3"
  ]
}

3. Génère EXACTEMENT 6 semaines
4. 3-4 séances par semaine maximum
5. Durée entre 20 et 90 minutes par séance
6. Progression graduelle semaine après semaine
7. Utilise UNIQUEMENT ces jours : Lundi, Mercredi, Vendredi, Dimanche
8. Intensité : "légère", "modérée", "élevée", "intense"
9. Inclus toujours 3 recommandations pratiques

STRUCTURE DE PROGRESSION :
- Semaines 1-2 : Adaptation et base
- Semaines 3-4 : Développement et renforcement
- Semaines 5-6 : Intensification et test`;

// ========== PROMPTS SPÉCIALISÉS PAR OBJECTIF ==========

export const TRAINING_PROMPTS = {
  // 🏃 Objectif : Améliorer l'endurance
  endurance: {
    name: "Améliorer l'endurance",
    systemPrompt: `${BASE_SYSTEM_PROMPT}

SPÉCIALISATION ENDURANCE :
- Focus : Course continue, allure modérée, volume progressif
- Séances types :
  * Course continue (30-60 min)
  * Endurance fondamentale (60-75% FCM)
  * Sorties longues le dimanche (+10% chaque semaine)
- Inclus : 1 séance de renforcement musculaire/semaine
- Progression : +5-10% de volume par semaine
- Éviter : Trop d'intensité, privilégier le volume`,
  },

  // 🎯 Objectif : Préparer un 10km
  race10k: {
    name: "Préparer un 10km",
    systemPrompt: `${BASE_SYSTEM_PROMPT}

SPÉCIALISATION 10KM :
- Focus : Allure spécifique 10km, VMA, économie de course
- Séances types :
  * Fractionné court (400m-1000m)
  * Tempo run à allure 10km (20-30 min)
  * Sortie longue endurance (60 min max)
- Inclus : 1 test de VMA en semaine 2
- Progression : Intensité > Volume
- Pic en semaine 5, récupération en semaine 6`,
  },

  // 🏆 Objectif : Préparer un semi-marathon
  raceSemi: {
    name: "Préparer un semi-marathon",
    systemPrompt: `${BASE_SYSTEM_PROMPT}

SPÉCIALISATION SEMI-MARATHON :
- Focus : Endurance active, allure semi, résistance
- Séances types :
  * Sortie longue progressive (jusqu'à 90 min)
  * Tempo run à allure semi (30-40 min)
  * Fractionné moyen (1000m-2000m)
- Inclus : Nutrition et hydratation dans les conseils
- Progression : Volume progressif, 1 sortie longue/semaine
- Pic en semaine 5 (18-20 km), affûtage semaine 6`,
  },

  // 💪 Objectif : Perte de poids
  weightLoss: {
    name: "Perte de poids",
    systemPrompt: `${BASE_SYSTEM_PROMPT}

SPÉCIALISATION PERTE DE POIDS :
- Focus : Cardio modéré, renforcement, régularité
- Séances types :
  * Course continue modérée (30-45 min)
  * HIIT court (15-20 min)
  * Renforcement musculaire (2x/semaine)
- Fréquence : 4 séances/semaine (Lundi, Mercredi, Vendredi, Dimanche)
- Intensité : 60-75% FCM pour brûler les graisses
- Inclus : Conseils nutrition et récupération`,
  },

  // ⚡ Objectif : Améliorer la vitesse
  speed: {
    name: "Améliorer la vitesse",
    systemPrompt: `${BASE_SYSTEM_PROMPT}

SPÉCIALISATION VITESSE / VMA :
- Focus : Fractionné court, explosivité, technique de course
- Séances types :
  * Fractionné court intense (200m-400m à 95-100% VMA)
  * Côtes courtes explosives
  * Foulées bondissantes
  * Éducatifs de course
- Inclus : Échauffement détaillé (15 min minimum)
- Récupération : 2-3 min entre répétitions
- Volume modéré, intensité élevée`,
  },

  // 🔰 Objectif : Débutant - Découverte course
  beginner: {
    name: "Débutant - Découverte",
    systemPrompt: `${BASE_SYSTEM_PROMPT}

SPÉCIALISATION DÉBUTANT :
- Focus : Alternance marche/course, progression douce
- Séances types :
  * Marche/course (ex: 1 min course / 1 min marche)
  * Course continue très courte (10-15 min max semaine 1)
  * Renforcement léger (gainage, proprioception)
- Progression : +2-3 min de course par semaine
- Durée : 20-30 min max
- Intensité : Toujours "légère" à "modérée"
- Inclus : Prévention blessures, choix chaussures`,
  },

  // 🔄 Objectif : Reprise après pause
  comeback: {
    name: "Reprise après pause",
    systemPrompt: `${BASE_SYSTEM_PROMPT}

SPÉCIALISATION REPRISE :
- Focus : Reconditionnement progressif, écoute du corps
- Semaines 1-2 : Volume très modéré (20-30 min)
- Semaines 3-4 : Augmentation progressive
- Semaines 5-6 : Retour à un niveau intermédiaire
- Inclus : Renforcement musculaire préventif
- Intensité : Privilégier endurance sur vitesse
- Conseils : Étirements, récupération active`,
  },
};

// ========== FONCTION POUR OBTENIR LE PROMPT ==========
export function getTrainingPrompt(objectiveKey: string): string {
  const prompt = TRAINING_PROMPTS[objectiveKey as keyof typeof TRAINING_PROMPTS];
  
  if (!prompt) {
    console.warn(`Objectif "${objectiveKey}" non trouvé, utilisation du prompt endurance par défaut`);
    return TRAINING_PROMPTS.endurance.systemPrompt;
  }
  
  return prompt.systemPrompt;
}

// ========== LISTE DES OBJECTIFS DISPONIBLES ==========
export function getAvailableObjectives(): Array<{ key: string; name: string }> {
  return Object.entries(TRAINING_PROMPTS).map(([key, value]) => ({
    key,
    name: value.name,
  }));
}

// ========== VALIDATION DU JSON RETOURNÉ ==========
export function validateTrainingPlan(data: any): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Vérifier la structure de base
  if (!data.objective) errors.push('Missing: objective');
  if (!data.startDate) errors.push('Missing: startDate');
  if (!data.duration) errors.push('Missing: duration');
  if (!Array.isArray(data.weeks)) errors.push('Missing or invalid: weeks');
  if (!Array.isArray(data.recommendations)) errors.push('Missing or invalid: recommendations');

  // Vérifier qu'il y a 6 semaines
  if (data.weeks && data.weeks.length !== 6) {
    errors.push(`Expected 6 weeks, got ${data.weeks.length}`);
  }

  // Vérifier chaque semaine
  if (Array.isArray(data.weeks)) {
    data.weeks.forEach((week: any, index: number) => {
      if (!week.weekNumber) errors.push(`Week ${index + 1}: missing weekNumber`);
      if (!week.weekTitle) errors.push(`Week ${index + 1}: missing weekTitle`);
      if (!Array.isArray(week.sessions)) errors.push(`Week ${index + 1}: invalid sessions`);

      // Vérifier chaque session
      if (Array.isArray(week.sessions)) {
        week.sessions.forEach((session: any, sessionIndex: number) => {
          if (!session.day) errors.push(`Week ${index + 1}, Session ${sessionIndex + 1}: missing day`);
          if (!session.title) errors.push(`Week ${index + 1}, Session ${sessionIndex + 1}: missing title`);
          if (!session.description) errors.push(`Week ${index + 1}, Session ${sessionIndex + 1}: missing description`);
          if (typeof session.duration !== 'number') errors.push(`Week ${index + 1}, Session ${sessionIndex + 1}: invalid duration`);
        });
      }
    });
  }

  // Vérifier les recommandations
  if (Array.isArray(data.recommendations) && data.recommendations.length < 3) {
    errors.push(`Expected at least 3 recommendations, got ${data.recommendations.length}`);
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}