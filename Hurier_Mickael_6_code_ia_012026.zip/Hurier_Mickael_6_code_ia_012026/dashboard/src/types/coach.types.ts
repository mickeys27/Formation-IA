// src/types/coach.types.ts

export interface TrainingSession {
  day: string;
  title: string;
  description: string;
  duration: number;
  intensity: string;
  targetMuscles: string;
}

export interface TrainingWeek {
  weekNumber: number;
  weekTitle: string;
  sessions: TrainingSession[];
}

export interface TrainingProgram {
  objective: string;
  startDate: string;
  duration: string;
  weeks: TrainingWeek[];
  recommendations: string[];
}

export interface ProgramResponse {
  success: boolean;
  program: TrainingProgram;
  metadata: {
    generatedAt: string;
    userId: number;
    model: string;
  };
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
}

export interface CoachChatRequest {
  message: string;
  conversationHistory?: ChatMessage[];
}

export interface CoachChatResponse {
  success: boolean;
  message: string;
  timestamp: string;
  metadata: {
    userId: number;
    model: string;
  };
}

export interface ProgramRequest {
  objective: string;
  startDate: string;
}