// utils/routes.ts

export interface Route {
  path: string;
  name: string;
  requiresAuth: boolean;
}

export const routes: Route[] = [
  {
    path: '/login',
    name: 'Connexion',
    requiresAuth: false,
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    requiresAuth: true,
  },
  {
    path: '/profile',
    name: 'Mon profil',
    requiresAuth: true,
  },
  {
    path: '/coach-ai',
    name: 'Coach AI',
    requiresAuth: true,
  },
];

export function isRouteProtected(pathname: string): boolean {
  const route = routes.find((r) => r.path === pathname);
  return route ? route.requiresAuth : false;
}