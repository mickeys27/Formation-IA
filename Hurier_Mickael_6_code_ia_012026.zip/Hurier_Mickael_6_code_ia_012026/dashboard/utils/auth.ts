'use client';

/**
 * 🍪 Gestion des cookies d'authentification
 */

/**
 * Stocke le token d'authentification dans un cookie
 * @param token - Le token JWT à stocker
 */
export const setAuthToken = (token: string): void => {
  if (typeof window === 'undefined') return;
  
  const unJourEnSecondes = 60 * 60 * 24;
  document.cookie = `auth_token=${token}; path=/; max-age=${unJourEnSecondes}; SameSite=Strict`;
  
  console.log('✅ Token sauvegardé');
};

/**
 * Récupère le token d'authentification depuis les cookies
 * @returns Le token ou null s'il n'existe pas
 */
export const getAuthToken = (): string | null => {
  // Vérification côté client uniquement
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return null;
  }
  
  try {
    const match = document.cookie.match(/auth_token=([^;]+)/);
    return match ? match[1] : null;
  } catch (error) {
    console.error('Erreur lors de la récupération du token:', error);
    return null;
  }
};

/**
 * Supprime le token d'authentification
 */
export const removeAuthToken = (): void => {
  if (typeof window === 'undefined') return;
  
  document.cookie = 'auth_token=; path=/; max-age=0';
  console.log('🚪 Token supprimé');
};

/**
 * Vérifie si l'utilisateur est authentifié
 * @returns true si un token existe, false sinon
 */
export const isAuthenticated = (): boolean => {
  return !!getAuthToken();
};