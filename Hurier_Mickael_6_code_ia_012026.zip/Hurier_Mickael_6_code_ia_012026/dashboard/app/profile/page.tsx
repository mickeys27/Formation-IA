// app/profile/page.tsx
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/contexts/UserContext';
import { useUserInfo } from '@/src/hooks/useUserInfo';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { ErrorMessage } from '@/components/ErrorMessage';
import './profile.css';
export default function ProfilePage() {
  const router = useRouter();
  const { isAuthenticated, loading: authLoading } = useUser();

  // ✅ Charger les données utilisateur depuis l'API
  const { 
    data: userInfo, 
    loading: userInfoLoading, 
    error: userInfoError,
    refetch: refetchUserInfo 
  } = useUserInfo();

  // ✅ Rediriger si non authentifié
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, authLoading, router]);

  // ✅ États de chargement
  if (authLoading || !isAuthenticated) {
    return <LoadingSpinner />;
  }

  if (userInfoLoading) {
    return <LoadingSpinner />;
  }

  // ✅ Gestion des erreurs
  if (userInfoError) {
    return (
      <div className="dashboard-container">
        <ErrorMessage 
          message={userInfoError} 
          onRetry={refetchUserInfo}
        />
      </div>
    );
  }

  if (!userInfo) {
    return (
      <div className="dashboard-container">
        <ErrorMessage 
          message="Aucune donnée disponible" 
          onRetry={refetchUserInfo}
        />
      </div>
    );
  }

  const { profile, statistics } = userInfo;

  return (
    <div className="dashboard-container">
      <div className="dashboard-wrapper">
        
        <div className="dashboard-grid">
          
          {/* ========== COLONNE GAUCHE : PROFIL ========== */}
          <div className="profile-column">
            
            {/* Carte Profil Utilisateur */}
            <div className="profile-card">
              <div className="profile-header">
                {/* Photo de profil */}
                <div className="profile-avatar">
                  <img
                    src={profile.profilePicture}
                    alt={`${profile.firstName} ${profile.lastName}`}
                    onError={(e) => {
                      e.currentTarget.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="112" height="112"%3E%3Crect width="112" height="112" fill="%23e5e7eb" rx="24"/%3E%3Ctext x="50%25" y="50%25" dominant-baseline="middle" text-anchor="middle" font-size="48" fill="%239ca3af"%3E👤%3C/text%3E%3C/svg%3E';
                    }}
                  />
                </div>
                
                {/* Informations */}
                <div className="profile-info">
                  <h2 className="profile-name">
                    {profile.firstName} {profile.lastName}
                  </h2>
                  <p className="profile-date">
                    Membre depuis le {new Date(profile.createdAt).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </p>
                </div>
              </div>
            </div>

            {/* Carte Votre profil */}
            <div className="profile-details-card">
              <h3 className="profile-details-title">Votre profil</h3>
              
              <div className="profile-details-list">
                <div className="profile-detail-item">
                  <span className="detail-label">Âge :</span>
                  <span className="detail-value">{profile.age} ans</span>
                </div>
                
                <div className="profile-detail-item">
                  <span className="detail-label">Genre :</span>
                  <span className="detail-value">Femme</span>
                </div>
                
                <div className="profile-detail-item">
                  <span className="detail-label">Taille :</span>
                  <span className="detail-value">{profile.height} cm</span>
                </div>
                
                <div className="profile-detail-item">
                  <span className="detail-label">Poids :</span>
                  <span className="detail-value">{profile.weight} kg</span>
                </div>
              </div>
            </div>
          </div>

          {/* ========== COLONNE DROITE : STATISTIQUES ========== */}
          <div className="stats-column">
            {/* En-tête */}
            <div className="stats-header">
              <h1 className="stats-title">Vos statistiques</h1>
              <p className="stats-subtitle">
                depuis le {new Date(profile.createdAt).toLocaleDateString('fr-FR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric'
                })}
              </p>
            </div>

            {/* Grille de cartes statistiques */}
            <div className="stats-grid">
              
              {/* Temps total couru */}
              <div className="stat-card">
                <p className="stat-label">Temps total couru</p>
                <div className="stat-value-wrapper">
                  <span className="stat-value-main">
                    {Math.floor(statistics.totalDuration / 60)}h
                  </span>
                  <span className="stat-value-unit">
                    {statistics.totalDuration % 60}min
                  </span>
                </div>
              </div>

              {/* Calories brûlées */}
              <div className="stat-card">
                <p className="stat-label">Calories brûlées</p>
                <div className="stat-value-wrapper">
                  <span className="stat-value-main">25000</span>
                  <span className="stat-value-unit">cal</span>
                </div>
              </div>

              {/* Distance totale parcourue */}
              <div className="stat-card">
                <p className="stat-label">Distance totale parcourue</p>
                <div className="stat-value-wrapper">
                  <span className="stat-value-main">
                    {Math.round(statistics.totalDistance)}
                  </span>
                  <span className="stat-value-unit">km</span>
                </div>
              </div>

              {/* Nombre de jours de repos */}
              <div className="stat-card">
                <p className="stat-label">Nombre de jours de repos</p>
                <div className="stat-value-wrapper">
                  <span className="stat-value-main">9</span>
                  <span className="stat-value-unit">jours</span>
                </div>
              </div>

              {/* Nombre de sessions - Sur 2 colonnes */}
              <div className="stat-card stat-card-wide">
                <p className="stat-label">Nombre de sessions</p>
                <div className="stat-value-wrapper">
                  <span className="stat-value-main">
                    {statistics.totalSessions}
                  </span>
                  <span className="stat-value-unit">sessions</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}