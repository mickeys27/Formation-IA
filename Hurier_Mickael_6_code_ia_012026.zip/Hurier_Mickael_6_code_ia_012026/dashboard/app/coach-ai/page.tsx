// app/coach-ai/page.tsx
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useCoach } from '@/contexts/CoachContext';
import { useUser } from '@/contexts/UserContext';
import './coach-ai.css';

export default function CoachAIPage() {
  const { openCoachModal, isCoachModalOpen } = useCoach();
  const { isAuthenticated, loading } = useUser();
  const router = useRouter();

  // Ouvrir le modal automatiquement au chargement de la page
  useEffect(() => {
    if (isAuthenticated && !loading) {
      openCoachModal();
    }
  }, [isAuthenticated, loading, openCoachModal]);

  // Rediriger vers le dashboard quand le modal se ferme
  useEffect(() => {
    if (!isCoachModalOpen && isAuthenticated && !loading) {
      // Petit délai pour une transition plus fluide
      const timer = setTimeout(() => {
        router.push('/dashboard');
      }, 300);
      
      return () => clearTimeout(timer);
    }
  }, [isCoachModalOpen, router, isAuthenticated, loading]);

  // Si pas authentifié, rediriger vers login
  useEffect(() => {
    if (!isAuthenticated && !loading) {
      router.push('/login');
    }
  }, [isAuthenticated, loading, router]);

  return (
    <div className="coach-ai-page">
      <div className="coach-ai-page__content">
        <h1 className="coach-ai-page__title">
          🤖 Chargement du Coach IA...
        </h1>
        <div className="coach-ai-page__spinner"></div>
        <p className="coach-ai-page__subtitle">
          Votre coach virtuel arrive dans un instant
        </p>
      </div>
    </div>
  );
}