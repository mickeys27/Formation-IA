// src/components/LoadingSpinner.tsx

export function LoadingSpinner() {
  return (
    <div className="loading-container">
      <div className="loading-spinner"></div>
      <p className="loading-text">Chargement des données...</p>
    </div>
  );
}