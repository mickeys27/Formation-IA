// components/TrainingPlan/TrainingPlan.tsx
'use client';

import { useState } from 'react';
import { ProgramResponse, TrainingWeek } from '@/src/types/coach.types';
import './TrainingPlan.css';

type Step = 'intro' | 'goal' | 'startDate' | 'result';

// ✅ Interface locale simplifiée pour l'affichage
interface WeekProgram {
  weekNumber: number;
  weekTitle: string;
  days: {
    day: string;
    dayName: string;
    title: string;
    description: string;
    duration: number;
  }[];
}

export default function TrainingPlan() {
  const [currentStep, setCurrentStep] = useState<Step>('intro');
  const [goal, setGoal] = useState('');
  const [startDate, setStartDate] = useState('');
  const [program, setProgram] = useState<WeekProgram[]>([]);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [expandedWeeks, setExpandedWeeks] = useState<number[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // ✅ Étape 1 → Étape 2
  const handleStart = () => {
    setCurrentStep('goal');
  };

  // ✅ Étape 2 → Étape 3
  const handleGoalSubmit = () => {
    if (goal.trim()) {
      setCurrentStep('startDate');
    }
  };

  // ✅ Étape 3 → Étape 4 (Génération du planning avec aiService)
  const handleGeneratePlanning = async () => {
    if (!startDate) return;

    setIsGenerating(true);
    setError(null);

    try {
      // ✅ Import dynamique du service AI
      const { aiService } = await import('@/src/services/aiService');
      
      // ✅ Appel API avec les bons paramètres
      const response: ProgramResponse = await aiService.generateProgram({
        objective: goal,
        startDate,
      });
      
      // ✅ Vérifier le succès de la réponse
      if (!response.success) {
        throw new Error('La génération du programme a échoué');
      }

      // ✅ Vérifier que la réponse contient un programme valide
      if (!response.program || !response.program.weeks || !Array.isArray(response.program.weeks)) {
        throw new Error('Format de réponse invalide');
      }

      // ✅ Transformer le format API vers le format du composant
      const transformedProgram: WeekProgram[] = response.program.weeks.map((week: TrainingWeek) => ({
        weekNumber: week.weekNumber,
        weekTitle: week.weekTitle,
        days: week.sessions.map((session) => ({
          day: session.day,
          dayName: session.day,
          title: session.title,
          description: session.description,
          duration: session.duration,
        }))
      }));

      setProgram(transformedProgram);
      setRecommendations(response.program.recommendations || []);
      setCurrentStep('result');
    } catch (err) {
      console.error('Erreur génération planning:', err);
      
      // Gestion des erreurs spécifiques
      if (err instanceof Error) {
        if (err.message.includes('401') || err.message.includes('Authentication')) {
          setError('Session expirée. Veuillez vous reconnecter.');
        } else if (err.message.includes('429')) {
          setError('Trop de requêtes. Veuillez réessayer dans quelques instants.');
        } else if (err.message.includes('504')) {
          setError('Délai d\'attente dépassé. Veuillez réessayer.');
        } else {
          setError(err.message);
        }
      } else {
        setError('Une erreur est survenue lors de la génération du programme.');
      }
    } finally {
      setIsGenerating(false);
    }
  };

  // ✅ Retour à l'étape précédente
  const handleBack = () => {
    if (currentStep === 'startDate') {
      setCurrentStep('goal');
    } else if (currentStep === 'goal') {
      setCurrentStep('intro');
    }
  };

  // ✅ Toggle accordion semaine
  const toggleWeek = (weekNumber: number) => {
    setExpandedWeeks(prev => 
      prev.includes(weekNumber)
        ? prev.filter(w => w !== weekNumber)
        : [...prev, weekNumber]
    );
  };

  // ✅ Télécharger le fichier ICS
  const handleDownloadICS = () => {
    const icsContent = generateICSFile(program, startDate);
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'planning-entrainement.ics';
    link.click();
  };

  // ✅ Régénérer un nouveau programme
  const handleRegenerate = () => {
    setGoal('');
    setStartDate('');
    setProgram([]);
    setRecommendations([]);
    setExpandedWeeks([]);
    setError(null);
    setCurrentStep('intro');
  };

  return (
    <div className="training-plan-container">
      {/* ========== ÉTAPE 1 : INTRO ========== */}
      {currentStep === 'intro' && (
        <div className="training-plan-card">
          <div className="plan-icon">📅</div>
          <h2 className="plan-title">Créez votre planning d'entraînement intelligent</h2>
          <p className="plan-description">
            Notre IA vous aide à bâtir un planning 100 % personnalisé selon vos objectifs, votre niveau et votre emploi du temps.
          </p>
          <button onClick={handleStart} className="btn-primary-plan">
            Commencer
          </button>
        </div>
      )}

      {/* ========== ÉTAPE 2 : OBJECTIF ========== */}
      {currentStep === 'goal' && (
        <div className="training-plan-card">
          <div className="plan-icon">🎯</div>
          <h2 className="plan-title">Quel est votre objectif principal ?</h2>
          <p className="plan-description">
            Choisissez l'objectif qui vous motive le plus
          </p>
          <div className="form-group">
            <label htmlFor="goal-input" className="form-label">Objectif</label>
            <input
              id="goal-input"
              type="text"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="Ex: Perdre du poids, courir un 10km, gagner en endurance..."
              className="form-input"
              onKeyDown={(e) => e.key === 'Enter' && handleGoalSubmit()}
            />
          </div>
          <button
            onClick={handleGoalSubmit}
            disabled={!goal.trim()}
            className="btn-primary-plan"
          >
            Suivant
          </button>
        </div>
      )}

      {/* ========== ÉTAPE 3 : DATE DE DÉBUT ========== */}
      {currentStep === 'startDate' && (
        <div className="training-plan-card">
          <div className="plan-icon">📅</div>
          <h2 className="plan-title">Quand souhaitez-vous commencer votre programme ?</h2>
          <p className="plan-description">
            Générer un programme de 6 semaines à partir de la date de votre choix
          </p>
          <div className="form-group">
            <label htmlFor="date-input" className="form-label">Date de début</label>
            <input
              id="date-input"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className="form-input"
            />
          </div>
          
          {error && (
            <div className="error-banner">
              <span className="error-icon">⚠️</span>
              <span className="error-text">{error}</span>
            </div>
          )}

          <div className="button-group">
            <button onClick={handleBack} className="btn-back">
              ← Retour
            </button>
            <button
              onClick={handleGeneratePlanning}
              disabled={!startDate || isGenerating}
              className="btn-primary-plan"
            >
              {isGenerating ? 'Génération...' : 'Générer mon planning'}
            </button>
          </div>
        </div>
      )}

      {/* ========== ÉTAPE 4 : RÉSULTAT ========== */}
      {currentStep === 'result' && (
        <div className="training-plan-result">
          <div className="result-header">
            <h2 className="result-title">Votre planning de 6 semaines</h2>
            <p className="result-subtitle">Programme personnalisé pour atteindre vos objectifs</p>
          </div>

          <div className="weeks-list">
            {program.map((week) => (
              <div key={week.weekNumber} className="week-card">
                <button
                  onClick={() => toggleWeek(week.weekNumber)}
                  className="week-header"
                >
                  <span className="week-title">Semaine {week.weekNumber}</span>
                  <span className={`week-toggle ${expandedWeeks.includes(week.weekNumber) ? 'expanded' : ''}`}>
                    {expandedWeeks.includes(week.weekNumber) ? '−' : '+'}
                  </span>
                </button>

                {expandedWeeks.includes(week.weekNumber) && (
                  <div className="week-content">
                    {week.days.map((day, index) => (
                      <div key={index} className="day-workout">
                        <div className="day-header">
                          <span className="day-name">{day.dayName}</span>
                        </div>
                        <div className="workout-details">
                          <h4 className="workout-title">{day.title}</h4>
                          <p className="workout-description">{day.description}</p>
                        </div>
                        <div className="workout-duration">{day.duration}min</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* ✅ Recommandations */}
          {recommendations.length > 0 && (
            <div className="recommendations-section">
              <h3 className="recommendations-title">📌 Recommandations</h3>
              <ul className="recommendations-list">
                {recommendations.map((rec, index) => (
                  <li key={index} className="recommendation-item">
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="result-actions">
            <button onClick={handleDownloadICS} className="btn-secondary-plan">
              Télécharger
            </button>
            <button onClick={handleRegenerate} className="btn-primary-plan">
              Regénérer un programme
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== FONCTIONS UTILITAIRES ==========

// ✅ Générer le fichier ICS pour export calendrier
function generateICSFile(program: WeekProgram[], startDate: string): string {
  const start = new Date(startDate);
  
  let ics = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//SportSee//Training Plan//FR
CALSCALE:GREGORIAN
METHOD:PUBLISH
X-WR-CALNAME:Planning Entraînement SportSee
X-WR-TIMEZONE:Europe/Paris
X-WR-CALDESC:Programme d'entraînement personnalisé\n`;

  program.forEach((week) => {
    week.days.forEach((day) => {
      const dayIndex = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'].indexOf(day.dayName);
      if (dayIndex === -1) return; // Skip si jour invalide
      
      const eventDate = new Date(start);
      eventDate.setDate(start.getDate() + (week.weekNumber - 1) * 7 + dayIndex);
      
      const startTime = new Date(eventDate);
      startTime.setHours(9, 0, 0);
      
      const endTime = new Date(startTime);
      endTime.setMinutes(startTime.getMinutes() + day.duration);

      const formatDate = (date: Date) => {
        return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      };

      ics += `BEGIN:VEVENT
UID:${Date.now()}-${week.weekNumber}-${dayIndex}@sportsee.com
DTSTAMP:${formatDate(new Date())}
DTSTART:${formatDate(startTime)}
DTEND:${formatDate(endTime)}
SUMMARY:${day.title}
DESCRIPTION:${day.description}\\nDurée: ${day.duration} minutes
LOCATION:SportSee
STATUS:CONFIRMED
END:VEVENT\n`;
    });
  });

  ics += 'END:VCALENDAR';
  return ics;
}