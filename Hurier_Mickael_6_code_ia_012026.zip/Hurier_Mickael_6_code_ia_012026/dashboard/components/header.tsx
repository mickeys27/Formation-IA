// components/header.tsx
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useUser } from '@/contexts/UserContext';
import { useCoach } from '@/contexts/CoachContext';
import { useEffect, useState } from 'react';
import './header.css';

export function Header() {
  const pathname = usePathname();
  const { user, logout } = useUser();
  const { openCoachModal, clearAllHistory } = useCoach();
  const [isMounted, setIsMounted] = useState(false);

  // ✅ Attendre que le composant soit monté côté client
  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleLogout = () => {
    console.log('🚪 Déconnexion en cours...');
    clearAllHistory();
    logout();
    window.location.href = '/login';
  };

  const handleCoachClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    openCoachModal();
  };

  // ✅ Ne pas afficher le header sur la page login
  if (pathname === '/login') {
    return null;
  }

  // ✅ Pendant l'hydratation, afficher une version simplifiée
  if (!isMounted) {
    return (
      <header className="header">
        <div className="header-container">
          <Link href="/" className="header-logo">
            <span className="logo-bars">|||</span>
            <span className="logo-text">SportSee</span>
          </Link>
          <nav className="header-nav">
            <Link href="/dashboard" className="nav-link">
              Dashboard
            </Link>
          </nav>
        </div>
      </header>
    );
  }

  return (
    <header className="header">
      <div className="header-container">
        {/* Logo */}
        <Link href="/" className="header-logo">
          <span className="logo-bars">|||</span>
          <span className="logo-text">SportSee</span>
        </Link>

        {/* Navigation */}
        <nav className="header-nav">
          <Link 
            href="/dashboard" 
            className={`nav-link ${pathname === '/dashboard' ? 'nav-link-active' : ''}`}
          >
            Dashboard
          </Link>
          <div className="nav-separator"></div>
          <Link 
            href="/profile" 
            className={`nav-link ${pathname === '/profile' ? 'nav-link-active' : ''}`}
          >
            Profil
          </Link>
          <div className="nav-separator"></div>
          
          {/* Bouton Coach IA */}
          <button 
            onClick={handleCoachClick}
            className="nav-link nav-button"
            type="button"
          >
            Coach IA
          </button>

          <div className="nav-separator"></div>
          <button 
            onClick={handleLogout}
            className="logout-button"
            type="button"
          >
            Déconnexion
          </button>
        </nav>
      </div>
    </header>
  );
}