// components/charts/DailyHeartRateChart.tsx
"use client";

import { useMemo, useState } from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { UserActivityResponse } from '@/src/mocks/api/user-activity.mock';

interface DailyHeartRateChartProps {
  activities: UserActivityResponse;
}

// Fonction pour obtenir le lundi d'une semaine donnée
function getMonday(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Ajuster si dimanche
  return new Date(d.setDate(diff));
}

// Fonction pour formatter une date en YYYY-MM-DD
function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

const getDailyData = (activities: UserActivityResponse, weekStart: Date) => {
  const dayNames = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  
  // Créer un tableau de 7 jours (Lun à Dim)
  const weekDays: {
    day: string;
    date: string;
    dateFormatted: string;
    min: number | null;
    max: number | null;
    avg: number | null;
    count: number;
  }[] = [];

  for (let i = 0; i < 7; i++) {
    const currentDate = new Date(weekStart);
    currentDate.setDate(weekStart.getDate() + i);
    
    weekDays.push({
      day: dayNames[i],
      date: formatDate(currentDate),
      dateFormatted: currentDate.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }),
      min: null,
      max: null,
      avg: null,
      count: 0,
    });
  }

  // Remplir avec les données des activités
  activities.forEach(activity => {
    const activityDate = new Date(activity.date);
    const dayIndex = weekDays.findIndex(d => d.date === formatDate(activityDate));
    
    if (dayIndex !== -1) {
      const day = weekDays[dayIndex];
      
      // Si première activité du jour
      if (day.count === 0) {
        day.min = activity.heartRate.min;
        day.max = activity.heartRate.max;
        day.avg = activity.heartRate.average;
        day.count = 1;
      } else {
        // Faire la moyenne si plusieurs activités le même jour
        day.min = Math.min(day.min!, activity.heartRate.min);
        day.max = Math.max(day.max!, activity.heartRate.max);
        day.avg = ((day.avg! * day.count) + activity.heartRate.average) / (day.count + 1);
        day.count++;
      }
    }
  });

  // Arrondir les moyennes
  return weekDays.map(d => ({
    ...d,
    avg: d.avg ? Math.round(d.avg) : null
  }));
};

export default function DailyHeartRateChart({ activities }: DailyHeartRateChartProps) {
  // État pour la semaine courante
  const [currentWeekStart, setCurrentWeekStart] = useState(() => {
    // Trouver la première activité pour initialiser la semaine
    if (activities.length > 0) {
     const sortedActivities = [...activities].sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime() // la plus recente
    );
    const lastActivityDate = new Date(sortedActivities[0].date);
    return getMonday(lastActivityDate);
    }
    return getMonday(new Date());
  });

  const data = useMemo(() => 
    getDailyData(activities, currentWeekStart), 
    [activities, currentWeekStart]
  );
  
  const avgBPM = useMemo(() => {
    const validAvgs = data.filter(d => d.avg !== null).map(d => d.avg!);
    if (validAvgs.length === 0) return 0;
    return Math.round(validAvgs.reduce((sum, val) => sum + val, 0) / validAvgs.length);
  }, [data]);

  // Navigation semaine précédente
  const goToPreviousWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() - 7);
    setCurrentWeekStart(newDate);
  };

  // Navigation semaine suivante
  const goToNextWeek = () => {
    const newDate = new Date(currentWeekStart);
    newDate.setDate(newDate.getDate() + 7);
    setCurrentWeekStart(newDate);
  };

  // Calculer la fin de la semaine
  const weekEnd = new Date(currentWeekStart);
  weekEnd.setDate(currentWeekStart.getDate() + 6);

  return (
    <div className="chart-card">
      <div className="chart-header">
        <h3 className="chart-title chart-title-red">
          {avgBPM} BPM
        </h3>
        <p className="chart-subtitle">
          Fréquence cardiaque moyenne
        </p>
         <p className="chart-subtitle">Affichage de la semaine de dernière activité</p>
      </div>

      <div className="chart-navigation">
        <button 
          className="nav-button" 
          onClick={goToPreviousWeek}
          aria-label="Semaine précédente"
        >
          ‹
        </button>
        <span className="nav-date">
          {currentWeekStart.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' ,year : 'numeric' })}
          {' - '}
          {weekEnd.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year : 'numeric' })}
        </span>
        <button 
          className="nav-button" 
          onClick={goToNextWeek}
          aria-label="Semaine suivante"
        >
          ›
        </button>
      </div>

      <ResponsiveContainer width="100%" height={260}>
        <ComposedChart 
          data={data} 
          margin={{ top: 20, right: 20, left: -10, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
          
          <XAxis 
            dataKey="day" 
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#86868b', fontSize: 13 }}
          />
          
          <YAxis 
            domain={[130, 190]}
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#86868b', fontSize: 13 }}
            ticks={[130, 145, 160, 175, 190]}
          />
          
          {/* Barre MIN (rose) */}
          <Bar 
            dataKey="min" 
            fill="#FFD1DC" 
            radius={[8, 8, 0, 0]}
            maxBarSize={35}
          />
          
          {/* Barre MAX (rouge) */}
          <Bar 
            dataKey="max" 
            fill="#ff3b30" 
            radius={[8, 8, 0, 0]}
            maxBarSize={35}
          />
          
          {/* Ligne MOYENNE (bleue avec points) */}
          <Line 
            type="monotone"
            dataKey="avg" 
            stroke="#d1d5db"
            strokeWidth={2}
            dot={(props: any) => {
              // N'afficher le point que s'il y a des données
              if (props.payload.avg === null) return null;
              return (
                <circle
                  cx={props.cx}
                  cy={props.cy}
                  r={5}
                  fill="#2f5de7"
                  stroke="white"
                  strokeWidth={2}
                />
              );
            }}
            activeDot={{ 
              r: 7, 
              fill: '#2f5de7',
              stroke: 'white',
              strokeWidth: 2
            }}
            connectNulls={false} // Ne pas connecter les jours sans données
          />
        </ComposedChart>
      </ResponsiveContainer>

      <div className="chart-legend">
        <div className="legend-item">
          <div className="legend-dot legend-dot-pink"></div>
          <span className="legend-label">Min BPM</span>
        </div>
        <div className="legend-item">
          <div className="legend-dot legend-dot-red"></div>
          <span className="legend-label">Max BPM</span>
        </div>
        <div className="legend-item">
          <div className="legend-dot legend-dot-blue"></div>
          <span className="legend-label">Moyenne</span>
        </div>
      </div>

      <style jsx>{`
        :global(.recharts-line-curve) {
          transition: stroke 0.3s ease;
        }
        :global(.recharts-line-curve:hover) {
          stroke: #2f5de7 !important;
        }
      `}</style>
    </div>
  );
}