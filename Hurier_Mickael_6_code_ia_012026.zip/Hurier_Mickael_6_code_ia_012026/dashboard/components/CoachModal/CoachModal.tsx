// components/CoachModal/CoachModal.tsx
'use client';

import React, { useState, useRef, useEffect } from 'react';
import { useCoach } from '../../contexts/CoachContext';
import { useUser } from '../../contexts/UserContext';
import { aiService } from '@/src/services/aiService';
import './CoachModal.css';

export const CoachModal: React.FC = () => {
  const {
    isCoachModalOpen,
    closeCoachModal,
    chatMessages,
    addMessage,
    isChatLoading,
    setChatLoading,
    chatError,
    setChatError,
    clearChat,
    conversationHistory,
    saveCurrentConversation,
    loadConversation, // ✅ AJOUTÉ
  } = useCoach();

  const { isAuthenticated } = useUser();

  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  // Focus textarea when modal opens
  useEffect(() => {
    if (isCoachModalOpen) {
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 100);
    }
  }, [isCoachModalOpen]);

  const handleSendMessage = async () => {
    const trimmedMessage = inputMessage.trim();
    
    if (!trimmedMessage || isChatLoading) {
      return;
    }

    // Check authentication
    if (!isAuthenticated) {
      setChatError('Vous devez être connecté pour utiliser le coach.');
      return;
    }

    // Limit message length
    if (trimmedMessage.length > 1000) {
      setChatError('Message trop long. Maximum 1000 caractères.');
      return;
    }

    // Add user message
    const userMessage = {
      role: 'user' as const,
      content: trimmedMessage,
      timestamp: new Date().toISOString(),
    };
    
    addMessage(userMessage);
    setInputMessage('');
    setChatError(null);
    setChatLoading(true);

    try {
      // Build conversation history (last 10 messages)
      const conversationHistoryForAPI = chatMessages
        .slice(-10)
        .map(msg => ({
          role: msg.role,
          content: msg.content,
        }));

      const response = await aiService.chatWithCoach({
        message: trimmedMessage,
        conversationHistory: conversationHistoryForAPI,
      });

      // Add assistant response
      const assistantMessage = {
        role: 'assistant' as const,
        content: response.message,
        timestamp: response.timestamp,
      };
      
      addMessage(assistantMessage);
    } catch (error) {
      console.error('Error sending message:', error);
      
      if (error && typeof error === 'object' && 'status' in error) {
        const err = error as { status: number; message: string };
        if (err.status === 401) {
          setChatError('Session expirée. Veuillez vous reconnecter.');
        } else if (err.status === 429) {
          setChatError('Trop de requêtes. Réessayez dans quelques instants.');
        } else if (err.status === 504) {
          setChatError('Délai d\'attente dépassé. Réessayez.');
        } else {
          setChatError(err.message || 'Une erreur est survenue');
        }
      } else {
        setChatError(error instanceof Error ? error.message : 'Une erreur est survenue');
      }
    } finally {
      setChatLoading(false);
    }
  };



  const handleCloseModal = () => {
    // Sauvegarder la conversation actuelle dans l'historique
    saveCurrentConversation();
    
    // Vider le chat actuel
    clearChat();
    
    // Fermer le modal
    closeCoachModal();
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleCloseModal();
    }
  };

  const formatDate = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) {
      return "À l'instant";
    } else if (diffInMinutes < 60) {
      return `Il y a ${diffInMinutes} min`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `Il y a ${hours}h`;
    } else {
      return date.toLocaleDateString('fr-FR', { 
        day: 'numeric', 
        month: 'short' 
      });
    }
  };

  if (!isCoachModalOpen) {
    return null;
  }

  return (
    <div className="coach-modal-overlay" onClick={handleOverlayClick}>
      <div 
        className={`coach-modal ${isCoachModalOpen ? 'coach-modal--open' : ''}`}
      >
        {/* Close button */}
        <button 
          className="coach-modal__close"
          onClick={(e) => {
            e.stopPropagation();
            handleCloseModal();
          }}
          aria-label="Fermer"
          type="button"
        >
          Fermer ✕
        </button>

        {/* Title Section */}
        <div className="coach-modal__title-section">
          <h2 className="coach-modal__title">
            Posez vos questions sur votre programme,<br />
            vos performances ou vos objectifs
          </h2>
        </div>

        {/* Messages */}
        <div className="coach-modal__messages">
          {chatMessages.length === 0 && (
            <div className="coach-modal__welcome">
              <p>👋 Bonjour ! Je suis votre coach virtuel.</p>
              <p>Posez-moi des questions sur votre entraînement, la nutrition, ou la récupération.</p>
            </div>
          )}
          
          {chatMessages.map((msg, index) => (
            <div 
              key={index}
              className={`coach-modal__message coach-modal__message--${msg.role}`}
            >
              <div className="coach-modal__message-content">
                {msg.content}
              </div>
              {msg.timestamp && (
                <div className="coach-modal__message-time">
                  {new Date(msg.timestamp).toLocaleTimeString('fr-FR', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              )}
            </div>
          ))}
          
          {isChatLoading && (
            <div className="coach-modal__message coach-modal__message--assistant">
              <div className="coach-modal__message-content">
                <div className="coach-modal__typing">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Error message */}
        {chatError && (
          <div className="coach-modal__error">
            ⚠️ {chatError}
          </div>
        )}

        {/* Input Section */}
        <div className="coach-modal__input-section">
          {/* Input + Send button */}
          <div className="coach-modal__input-container">
            <div className="coach-modal__input-wrapper">
              <span className="coach-modal__input-icon">✨</span>
              <textarea
                ref={textareaRef}
                className="coach-modal__input"
                placeholder="Comment puis-je vous aider ?"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={isChatLoading || !isAuthenticated}
                maxLength={1000}
                rows={1}
              />
            </div>
            <button
              className="coach-modal__send"
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isChatLoading || !isAuthenticated}
              type="button"
            >
              ↑
            </button>
          </div>

          {/* ✅ CORRIGÉ : Historique des conversations */}
          {chatMessages.length === 0 && conversationHistory.length > 0 && (
            <div className="coach-modal__history">
              <div className="coach-modal__history-title">
                Conversations récentes
              </div>
              {conversationHistory.map((conv) => (
                <button
                  key={conv.id}
                  className="coach-modal__history-item"
                  onClick={() => {
                    console.log('🖱️ Clic sur conversation:', conv.id);
                    loadConversation(conv.id); 
                  }}
                  type="button"
                >
                  <div className="coach-modal__history-date">
                    {formatDate(conv.timestamp)}
                  </div>
                  <div className="coach-modal__history-preview">
                    Vous: {conv.firstMessage}...
                  </div>
                  <div className="coach-modal__history-meta">
                    {conv.messageCount} messages
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Authentication warning */}
        {!isAuthenticated && (
          <div className="coach-modal__auth-warning">
            🔐 Connectez-vous pour utiliser le coach
          </div>
        )}
      </div>
    </div>
  );
};