// components/KpiCards.tsx
"use client";

import { userKpiCards } from '@/src/mocks/charts/user-kpi.series';

export default function KpiCards() {
  return (
    <div className="kpi-cards-grid">
      {userKpiCards.map((kpi) => (
        <div key={kpi.key} className="kpi-card">
          <p className="kpi-card-label">{kpi.label}</p>
          <div className="kpi-card-value-container">
            <span className="kpi-card-value">
              {kpi.value.toLocaleString('fr-FR')}
            </span>
            {kpi.unit && (
              <span className="kpi-card-unit">{kpi.unit}</span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}