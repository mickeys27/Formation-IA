// components/ClientProviders.tsx
'use client';

import { ReactNode } from 'react';
import { UserProvider } from '@/contexts/UserContext';
import { CoachProvider } from '@/contexts/CoachContext';
import { CoachModal } from '@/components/CoachModal/CoachModal';
import { Header } from '@/components/header';

export function ClientProviders({ children }: { children: ReactNode }) {
  return (
    <UserProvider>
      <CoachProvider>
        <Header />
        {children}
        <CoachModal />
      </CoachProvider>
    </UserProvider>
  );
}