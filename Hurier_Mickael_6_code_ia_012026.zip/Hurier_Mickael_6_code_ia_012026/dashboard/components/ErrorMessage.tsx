// src/components/ErrorMessage.tsx

interface ErrorMessageProps {
  message: string;
  onRetry?: () => void;
}

export function ErrorMessage({ message, onRetry }: ErrorMessageProps) {
  return (
    <div className="error-container">
      <h3 className="error-title">ATTENTION :  Une erreur est survenue</h3>
      <p className="error-message">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="error-button">
          Réessayer
        </button>
      )}
    </div>
  );
}