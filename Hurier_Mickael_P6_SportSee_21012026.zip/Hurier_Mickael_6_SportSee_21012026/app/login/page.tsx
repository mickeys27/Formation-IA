// app/login/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useUser } from '@/contexts/UserContext';
import './login.css';

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { login, isAuthenticated } = useUser();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // ✅ Récupérer l'URL de redirection si elle existe
  const redirectUrl = searchParams.get('redirect') || '/dashboard';

  // ✅ Rediriger si déjà connecté
  useEffect(() => {
    if (isAuthenticated) {
      console.log('✅ Already authenticated, redirecting to', redirectUrl);
      router.push(redirectUrl);
    }
  }, [isAuthenticated, router, redirectUrl]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    console.log('🔐 Attempting login with:', { username });

    try {
      await login(username, password);
      console.log('✅ Login successful, redirecting to', redirectUrl);
      
      // ✅ Redirection avec window.location pour forcer le rechargement
      window.location.href = redirectUrl;
      
    } catch (err) {
      console.error('❌ Login error:', err);
      setError('Identifiants incorrects');
      setLoading(false);
    }
  };

  return (
    <main className="login-page">
      <div className="login-container">
        <h1>Connexion</h1>
        
        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label htmlFor="username">Nom d'utilisateur</label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="sophiemartin"
              required
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Mot de passe</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password123"
              required
              disabled={loading}
            />
          </div>

          {error && <p className="error-text">{error}</p>}

          <button type="submit" disabled={loading} className="btn-primary">
            {loading ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>
      </div>
    </main>
  );
}