
import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="text-center px-4">
        {/* Numéro d'erreur */}
        <h1 className="text-9xl font-bold text-blue-600 mb-4">
          404
        </h1>
        
        {/* Titre */}
        <h2 className="text-3xl font-semibold text-gray-800 mb-2">
          Page introuvable
        </h2>
        
        {/* Message */}
        <p className="text-gray-600 mb-8 max-w-md mx-auto">
          Désolé, la page que vous recherchez n'existe pas ou a été déplacée.
        </p>
        
        {/* Boutons d'action */}
        <div className="flex gap-4 justify-center">
          <Link
            href="/dashboard"
            className="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Retour au Dashboard
          </Link>
          
          <Link
            href="/login"
            className="inline-block bg-gray-200 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-300 transition-colors font-medium"
          >
            Page de connexion
          </Link>
        </div>
      </div>
    </div>
  );
}