// app/dashboard/page.tsx
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/contexts/UserContext';
import { useUserInfo } from '@/src/hooks/useUserInfo';
import { useUserActivity } from '@/src/hooks/useUserActivity';
import WeeklyDistanceChart from '@/components/charts/WeeklyDistanceChart';
import DailyHeartRateChart from '@/components/charts/DailyHeartRateChart';
import WeeklySummary from '@/components/charts/WeeklySummary';
import KpiCards from '@/components/KpiCards';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { ErrorMessage } from '@/components/ErrorMessage';
import './dashboard.css';

export default function DashboardPage() {
  const router = useRouter();
  const { isAuthenticated, loading: authLoading } = useUser();

  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, authLoading, router]);

  const { 
    data: userInfo, 
    loading: userInfoLoading, 
    error: userInfoError,
    refetch: refetchUserInfo 
  } = useUserInfo();


const today = new Date();
const twoYearsAgo = new Date();
twoYearsAgo.setFullYear(today.getFullYear() - 2);
// Format YYYY-MM-DD
const formatDate = (date: Date) =>
  date.toISOString().split('T')[0];

  const { 
    data: userActivity, 
    loading: activityLoading, 
    error: activityError,
    refetch: refetchActivity ,
  } = useUserActivity({
  startWeek: formatDate(twoYearsAgo),
  endWeek: formatDate(today),
  });

  if (authLoading || !isAuthenticated) {
    return (
      <main className="dashboard">
        <LoadingSpinner />
      </main>
    );
  }

  if (userInfoLoading || activityLoading) {
    return (
      <main className="dashboard">
        <LoadingSpinner />
      </main>
    );
  }

  if (userInfoError) {
    return (
      <main className="dashboard">
        <ErrorMessage 
          message={userInfoError} 
          onRetry={refetchUserInfo}
        />
      </main>
    );
  }

  if (activityError) {
    return (
      <main className="dashboard">
        <ErrorMessage 
          message={activityError} 
          onRetry={refetchActivity}
        />
      </main>
    );
  }

  if (!userInfo || !userActivity) {
    return (
      <main className="dashboard">
        <ErrorMessage 
          message="Aucune donnée disponible" 
          onRetry={() => {
            refetchUserInfo();
            refetchActivity();
          }}
        />
      </main>
    );
  }

  const { profile, statistics } = userInfo;

  return (
    <main className="dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <span className="header-icon">⭐</span>
          <p className="header-text">
            Posez vos questions sur votre programme, vos performances ou vos objectifs.
          </p>
        </div>
        <button className="btn-primary">
          Lancer une conversation
        </button>
      </header>

      <section className="profile-section">
        <div className="profile-info">
          <img 
            src={profile.profilePicture} 
            alt={`${profile.firstName} ${profile.lastName}`}
            className="profile-picture"
          />
          
          <div className="profile-details">
            <h1 className="profile-name">
              {profile.firstName} {profile.lastName}
            </h1>
            <p className="profile-date">
              Membre depuis le {new Date(profile.createdAt).toLocaleDateString('fr-FR', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })}
            </p>
          </div>
        </div>

        <div className="distance-badge">
          <div className="badge-content">
            <span className="badge-icon">⚡</span>
            <span className="badge-value">{statistics.totalDistance} km</span>
          </div>
          <p className="badge-label">Distance totale parcourue</p>
        </div>
      </section>

     {/*  <KpiCards /> */}

        <section className="performances-section">
        <h2 className="section-title">Vos dernières performances</h2>        
        <div className="charts-grid">
          <WeeklyDistanceChart activities={userActivity} />
          <DailyHeartRateChart activities={userActivity} />         
      </div>        
          <WeeklySummary activities={userActivity} />      
      </section>
    </main>
  );
}