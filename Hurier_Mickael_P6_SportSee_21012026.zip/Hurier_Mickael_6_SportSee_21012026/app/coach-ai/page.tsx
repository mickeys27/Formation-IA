// app/dashboard/page.tsx
import { mockUserInfo } from '@/src/mocks/api/user-info.mock';
import WeeklyDistanceChart from '@/components/charts/WeeklyDistanceChart';
import DailyHeartRateChart from '@/components/charts/DailyHeartRateChart';

export default function DashboardPage() {
  const { profile, statistics } = mockUserInfo;
  
  return (
    <main className="dashboard">
      {/* Header avec bouton conversation */}
      <header className="dashboard-header">
        <div className="header-content">
          <span className="header-icon">🎯</span>
          <p className="header-text">
            Posez vos questions sur votre programme, vos performances ou vos objectifs.
          </p>
        </div>
        <button className="btn-primary">
          Lancer une conversation
        </button>
      </header>

      {/* Section Profil */}
      <section className="profile-section">
        <div className="profile-info">
          <img 
            src={profile.profilePicture} 
            alt={`${profile.firstName} ${profile.lastName}`}
            className="profile-picture"
          />
          
          <div className="profile-details">
            <h1 className="profile-name">
              {profile.firstName} {profile.lastName}
            </h1>
            <p className="profile-date">
              Membre depuis le {new Date(profile.createdAt).toLocaleDateString('fr-FR', { 
                day: 'numeric', 
                month: 'long', 
                year: 'numeric' 
              })}
            </p>
          </div>
        </div>

        <div className="distance-badge">
          <div className="badge-content">
            <span className="badge-icon">⚡</span>
            <span className="badge-value">{statistics.totalDistance} km</span>
          </div>
          <p className="badge-label">Distance totale parcourue</p>
        </div>
      </section>

      {/* Section Performances */}
      <section className="performances-section">
        <h2 className="section-title">Vos dernières performances</h2>
        
        <div className="charts-grid">
          <WeeklyDistanceChart />
          <DailyHeartRateChart />
        </div>
      </section>
    </main>
  );
}