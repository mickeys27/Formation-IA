// app/layout.tsx
import type { Metadata } from 'next';
import { Header } from '@/components/header';
import { UserProvider } from '@/contexts/UserContext';
import './global.css';



export const metadata: Metadata = {
  title: 'SportSee - Dashboard',
  description: 'Votre application de suivi sportif',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body>
        <UserProvider>
          <Header />
          <main>{children}</main>
        </UserProvider>
      </body>
    </html>
  );
}