import { mockUserInfo } from "../api/user-info.mock";

export type KpiCard = {
  key: "distance" | "sessions" | "duration";
  label: string;
  value: number;
  unit?: string;
};

const parseNumber = (v: string | number): number => {
  if (typeof v === "number") return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

export const userKpiCards: KpiCard[] = [
  {
    key: "distance",
    label: "Distance totale",
    value: parseNumber(mockUserInfo.statistics.totalDistance),
    unit: "km",
  },
  {
    key: "sessions",
    label: "Sessions",
    value: mockUserInfo.statistics.totalSessions,
  },
  {
    key: "duration",
    label: "Durée totale",
    value: mockUserInfo.statistics.totalDuration,
    unit: "min",
  },
];
