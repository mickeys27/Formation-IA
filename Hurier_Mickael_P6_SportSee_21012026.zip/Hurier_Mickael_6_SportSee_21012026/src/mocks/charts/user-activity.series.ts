import { mockUserActivity } from "../api/user-activity.mock";

export type UserActivityChartPoint = {
  date: string;
  distanceKm: number;
  durationMin: number;
  calories: number;
  hrAvg: number;
  hrMin: number;
  hrMax: number;
};

export const userActivitySeries: UserActivityChartPoint[] = [...mockUserActivity]
  .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  .map((s) => ({
    date: s.date,
    distanceKm: s.distance,
    durationMin: s.duration,
    calories: s.caloriesBurned,
    hrAvg: s.heartRate.average,
    hrMin: s.heartRate.min,
    hrMax: s.heartRate.max,
  }));
