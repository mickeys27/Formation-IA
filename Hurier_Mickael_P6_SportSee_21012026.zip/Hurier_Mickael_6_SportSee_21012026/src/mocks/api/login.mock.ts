'use client';
/**
 * 🔐 MOCK Login
 * Basé sur POST http://localhost:8000/api/login
 */

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  userId: string;
}

/**
 * Identifiants valides pour le mock
 */
const VALID_CREDENTIALS = [
  {
    username: "sophiemartin",
    password: "password123",
    userId: "user_sophie"
  },
  {
    username: "test@test.com",
    password: "test123",
    userId: "user_test"
  }
];

/**
 * Fonction mock qui simule l'appel API de connexion
 */
export const mockLogin = async (
  credentials: LoginRequest
): Promise<LoginResponse> => {
  // Simulation d'un délai réseau
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Vérification des identifiants
  const validUser = VALID_CREDENTIALS.find(
    cred => 
      cred.username === credentials.username && 
      cred.password === credentials.password
  );
  
  if (validUser) {
    // ✅ Connexion réussie
    return {
      token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJ1c2VyMTIzIn0.fake_signature_mock",
      userId: validUser.userId
    };
  } else {
    // ❌ Identifiants incorrects
    throw new Error("Identifiants incorrects");
  }
};

/**
 * 💡 UTILISATION EXEMPLE :
 * 
 * import { mockLogin } from '@/mocks/api/login.mock';
 * 
 * try {
 *   const response = await mockLogin({ 
 *     username: "sophiemartin", 
 *     password: "password123" 
 *   });
 *   console.log(response.token);
 * } catch (error) {
 *   console.error("Échec de connexion");
 * }
 */