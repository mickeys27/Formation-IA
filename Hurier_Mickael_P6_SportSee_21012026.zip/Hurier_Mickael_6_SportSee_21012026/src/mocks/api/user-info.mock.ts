/**
 * MOCK UserInfo
 * Basé sur GET http://localhost:8000/api/user-info
 */

export interface UserProfile {
  firstName: string;
  lastName: string;
  createdAt: string;
  age: number;
  weight: number;
  height: number;
  profilePicture: string;
}

export interface UserStatistics {
  totalDistance: number;
  totalSessions: number;
  totalDuration: number;
}

export interface UserInfoResponse {
  profile: UserProfile;
  statistics: UserStatistics;
}

/**
 * Données mockées correspondant à la réponse de l'API
 */
export const mockUserInfo: UserInfoResponse = {
  profile: {
    firstName: "Sophie",
    lastName: "Martin",
    createdAt: "2025-01-01",
    age: 32,
    weight: 60,
    height: 165,
    profilePicture: "http://localhost:8000/images/sophie.jpg"
  },
  statistics: {
    totalDistance: 2250.2,    // en km
    totalSessions: 348,        // nombre de sessions
    totalDuration: 14625       // en minutes
  }
};

/**
 * Fonction pour récupérer les infos utilisateur (simule l'API)
 */
export const getUserInfo = async (): Promise<UserInfoResponse> => {
  // Simulation d'un délai réseau
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return mockUserInfo;
};