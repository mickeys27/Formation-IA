// src/hooks/useUserInfo.ts
'use client';

import { useState, useEffect } from 'react';
import { fetchUserInfo } from '@/src/services/userService';
import { UserInfoResponse } from '@/src/mocks/api/user-info.mock';

interface UseUserInfoResult {
  data: UserInfoResponse | null;
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

export function useUserInfo(userId?: string): UseUserInfoResult {
  const [data, setData] = useState<UserInfoResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetchUserInfo();
      setData(response);
    } catch (err: any) {
      setError(err.message || 'Une erreur est survenue lors du chargement des données');
      console.error('❌ Erreur useUserInfo:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [userId]);

  return {
    data,
    loading,
    error,
    refetch: fetchData,
  };
}