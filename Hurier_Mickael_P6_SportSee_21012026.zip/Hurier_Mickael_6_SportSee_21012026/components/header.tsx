// components/header.tsx
'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useUser } from '@/contexts/UserContext';
import './header.css';

export function Header() {
  const router = useRouter();
  const { user, logout } = useUser();

  const handleLogout = () => {
    console.log('🚪 Déconnexion en cours...');
    
    // ✅ Appeler la fonction logout du contexte
    logout();
    
    // ✅ Redirection avec window.location pour forcer le rechargement
    window.location.href = '/login';
  };

  return (
    <header className="header">
      <div className="header-container">
        {/* Logo */}
        <Link href="/" className="header-logo">
          <span className="logo-bars">|||</span>
          <span className="logo-text">SportSee</span>
        </Link>

        {/* Navigation */}
        <nav className="header-nav">
          <Link href="/dashboard" className="nav-link">
            Dashboard
          </Link>
           <div className="nav-separator"></div>
          <Link href="/profile" className="nav-link">
            Profil
          </Link>
          <div className="nav-separator"></div>
          <Link href="/coach-ai" className="nav-link">
            Coach IA
          </Link>

          <div className="nav-separator"></div>
          {/* ✅ Bouton de déconnexion avec onClick */}
          <button 
            onClick={handleLogout}
            className="logout-button"
            type="button"
          >
            Déconnexion
          </button>
        </nav>
      </div>
    </header>
  );
}