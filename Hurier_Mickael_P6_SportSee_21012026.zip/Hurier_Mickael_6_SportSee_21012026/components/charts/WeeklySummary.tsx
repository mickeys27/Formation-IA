// components/charts/WeeklySummary.tsx
'use client';

import { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { UserActivityResponse } from '@/src/mocks/api/user-activity.mock';

interface WeeklySummaryProps {
  activities: UserActivityResponse;
}

// Fonction pour obtenir le lundi de la semaine en cours
function getMonday(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Ajuster si dimanche
  return new Date(d.setDate(diff));
}

export default function WeeklySummary({ activities }: WeeklySummaryProps) {
  // ✅ Calculer les stats de la SEMAINE EN COURS uniquement
  const stats = useMemo(() => {
    const now = new Date();
    const startOfWeek = new Date(getMonday(now));
    startOfWeek.setDate(getMonday(now).getDate() - 7); // - 1 semaine

    //const startOfWeek = getMonday(now);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6); // Dimanche

    // ✅ Filtrer les activités de cette semaine uniquement
    const weekActivities = activities.filter(activity => {
      const activityDate = new Date(activity.date);
      return activityDate >= startOfWeek && activityDate <= endOfWeek;
    });

    const completed = weekActivities.length;
    const goal = 6;
    const remaining = Math.max(0, goal - completed);
    
    const totalDuration = weekActivities.reduce((sum, a) => sum + a.duration, 0);
    const totalDistance = weekActivities.reduce((sum, a) => sum + a.distance, 0);

    return {
      completed,
      remaining,
      goal,
      totalDuration,
      totalDistance: Math.round(totalDistance * 10) / 10,
      startDate: startOfWeek,
      endDate: endOfWeek,
    };
  }, [activities]);

  // Données pour le graphique en donut
  const chartData = [
    { name: 'Réalisées', value: stats.completed, color: '#2f5de7' },
    { name: 'Restantes', value: stats.remaining, color: '#c7d2fe' },
  ];

  return (
    <section className="weekly-summary">
      <div className="weekly-header">
        <h2 className="weekly-title">Cette semaine / sur 2 semaines pour les tests </h2>
        <p className="weekly-date">
          Du {stats.startDate.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })}
          {' au '}
          {stats.endDate.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })}
        </p>
      </div>

      <div className="weekly-content">
        {/* Carte objectif avec graphique */}
        <div className="weekly-card">
          <div className="weekly-goal">
            <div className="goal-number">
              <span className="goal-value">x{stats.completed}</span>
              <span className="goal-text">sur objectif de {stats.goal}</span>
            </div>
            <p className="goal-label">Courses hebdomadaires réalisées</p>
          </div>

          {/* Graphique en donut */}
          <div className="weekly-chart">
            <ResponsiveContainer width={200} height={200}>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={0}
                  dataKey="value"
                  startAngle={90}
                  endAngle={450}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>

            {/* Légende sous le graphique */}
            <div className="chart-legend-donut">
              <div className="legend-item-donut">
                <div className="legend-dot" style={{ backgroundColor: '#2f5de7' }}></div>
                <span className="legend-text">{stats.completed} réalisées</span>
              </div>
              <div className="legend-item-donut">
                <div className="legend-dot" style={{ backgroundColor: '#c7d2fe' }}></div>
                <span className="legend-text">{stats.remaining} restantes</span>
              </div>
            </div>
          </div>
        </div>

        {/* Cartes statistiques */}
        <div className="weekly-stats">
          <div className="stat-card">
            <p className="stat-label">Durée d'activité</p>
            <p className="stat-value stat-value-blue">
              {stats.totalDuration} <span className="stat-unit">minutes</span>
            </p>
          </div>

          <div className="stat-card">
            <p className="stat-label">Distance</p>
            <p className="stat-value stat-value-red">
              {stats.totalDistance} <span className="stat-unit">kilomètres</span>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}