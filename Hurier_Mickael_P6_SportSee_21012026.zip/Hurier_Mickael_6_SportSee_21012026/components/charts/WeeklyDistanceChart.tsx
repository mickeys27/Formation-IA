// components/charts/WeeklyDistanceChart.tsx
"use client";

import { useMemo, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from 'recharts';
import { UserActivityResponse } from '@/src/mocks/api/user-activity.mock';

interface WeeklyDistanceChartProps {
  activities: UserActivityResponse;
}

// Fonction pour obtenir le lundi d'une semaine donnée
function getMonday(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff));
}

// Fonction pour formatter une date en YYYY-MM-DD
function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

// Fonction pour calculer les 4 dernières semaines
const getWeeklyData = (activities: UserActivityResponse, referenceDate: Date) => {
  const currentWeekMonday = getMonday(referenceDate);
  
  const weeks: {
    weekLabel: string;
    startDate: Date;
    endDate: Date;
    totalKm: number;
  }[] = [];

  for (let i = 3; i >= 0; i--) {
    const weekStart = new Date(currentWeekMonday);
    weekStart.setDate(currentWeekMonday.getDate() - (i * 7));
    
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    
    weeks.push({
      weekLabel: `S${4 - i}`,
      startDate: weekStart,
      endDate: weekEnd,
      totalKm: 0,
    });
  }

  // Remplir avec les distances des activités
  activities.forEach(activity => {
    const activityDate = new Date(activity.date);
    
    weeks.forEach(week => {
      if (activityDate >= week.startDate && activityDate <= week.endDate) {
        week.totalKm += activity.distance;
      }
    });
  });

  return weeks.map(w => ({
    week: w.weekLabel,
    totalKm: Math.round(w.totalKm * 10) / 10,
    dateRange: `${w.startDate.getDate()}/${w.startDate.getMonth() + 1}/${w.startDate.getFullYear()} - ${w.endDate.getDate()}/${w.endDate.getMonth() + 1}/${w.endDate.getFullYear()}`,
    startDate: formatDate(w.startDate),
    endDate: formatDate(w.endDate),
  }));
};

export default function WeeklyDistanceChart({ activities }: WeeklyDistanceChartProps) {
  const [referenceDate, setReferenceDate] = useState(() => new Date());

  const data = useMemo(() => 
    getWeeklyData(activities, referenceDate), 
    [activities, referenceDate]
  );
  
  const avgDistance = useMemo(() => {
    const total = data.reduce((sum, w) => sum + w.totalKm, 0);
    const count = data.filter(w => w.totalKm > 0).length || 1;
    return Math.round(total / count);
  }, [data]);

  const goToPreviousPeriod = () => {
    const newDate = new Date(referenceDate);
    newDate.setDate(newDate.getDate() - 28);
    setReferenceDate(newDate);
  };

  const goToNextPeriod = () => {
    const newDate = new Date(referenceDate);
    newDate.setDate(newDate.getDate() + 28);
    setReferenceDate(newDate);
  };

  const firstWeek = data[0];
  const lastWeek = data[data.length - 1];

  return (
    <div className="chart-card">
      <div className="chart-header">
        <h3 className="chart-title chart-title-blue">
          {avgDistance}km en moyenne
        </h3>
        <p className="chart-subtitle">
          Total des kilomètres 4 dernières semaines
        </p>
      </div>

      <div className="chart-navigation">
        <button 
          className="nav-button" 
          onClick={goToPreviousPeriod}
          aria-label="4 semaines précédentes"
        >
          ‹
        </button>
        <span className="nav-date">
          {firstWeek && lastWeek && (
            <>
              {new Date(firstWeek.startDate).toLocaleDateString('fr-FR', { 
                day: 'numeric', 
                month: 'short',
                year: 'numeric' // ✅ Ajout de l'année
              })}
              {' - '}
              {new Date(lastWeek.endDate).toLocaleDateString('fr-FR', { 
                day: 'numeric', 
                month: 'short',
                year: 'numeric' // ✅ Ajout de l'année
              })}
            </>
          )}
        </span>
        <button 
          className="nav-button" 
          onClick={goToNextPeriod}
          aria-label="4 semaines suivantes"
        >
          ›
        </button>
      </div>

      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data} margin={{ top: 20, right: 20, left: -10, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
          <XAxis 
            dataKey="week" 
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#86868b', fontSize: 13 }}
          />
          <YAxis 
            axisLine={false}
            tickLine={false}
            tick={{ fill: '#86868b', fontSize: 13 }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: 'white', 
              border: '1px solid #e5e5e7',
              borderRadius: '12px',
              padding: '12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
            }}
            labelFormatter={(label) => {
              const weekData = data.find(d => d.week === label);
              return weekData ? weekData.dateRange : label;
            }}
            formatter={(value: number | undefined) => {
              if (value === undefined) return ['N/A', 'Distance'];
              return [`${value} km`, 'Distance'];
            }}
          />
          <Bar 
            dataKey="totalKm" 
            fill="#8B7FFF" 
            radius={[10, 10, 0, 0]}
            maxBarSize={70}
          />
        </BarChart>
      </ResponsiveContainer>

      <div className="chart-legend">
        <div className="legend-item">
          <div className="legend-dot legend-dot-purple"></div>
          <span className="legend-label">Km</span>
        </div>
      </div>
    </div>
  );
}