import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const protectedRoutes = ['/dashboard', '/profile', '/coach-ai'];
const publicRoutes = ['/login', '/'];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  
  const token = request.cookies.get('token')?.value;
  const isAuthenticated = !!token;

  console.log('Middleware:', {
    pathname,
    isAuthenticated,
    hasToken: !!token
  });


  if (protectedRoutes.some(route => pathname.startsWith(route))) {
    if (!isAuthenticated) {
      console.log('Accès refusé à', pathname, '- Redirection vers /login');
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }
    console.log('Accès autorisé à', pathname);
  }


  if (pathname === '/login' && isAuthenticated) {
    console.log('Déjà connecté, redirection vers /dashboard');
    return NextResponse.redirect(new URL('/dashboard', request.url));
  }


  if (pathname === '/login') {
    console.log('Accès autorisé à /login');
    return NextResponse.next();
  }

  console.log('Accès autorisé à', pathname);
  return NextResponse.next();
}

export const config = {
  matcher: [
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};