"use client";

import { useState } from "react";
import Link from "next/link";
import styles from "./RestaurantCard.module.css";

export default function RestaurantCard({ restaurant }) {
  const { name, location, image, isNew, slug } = restaurant;
  const [liked, setLiked] = useState(false);

  const handleLike = (e) => {
    e.preventDefault(); // empêche la navigation quand on clique sur le coeur
    setLiked((prev) => !prev);
  };

  return (
    <Link href={`/restaurant/${slug}`} className={styles.cardLink}>
      <article className={styles.card}>
        <div className={styles.imageWrap}>
          {isNew && <span className={styles.badge}>Nouveau</span>}
          <img src={image} alt={name} className={styles.image} />
        </div>

        <div className={styles.content}>
          <div className={styles.text}>
            <h3 className={styles.title}>{name}</h3>
            <p className={styles.subtitle}>{location}</p>
          </div>

          <button
            className={`${styles.heart} ${liked ? styles.liked : ""}`}
            onClick={handleLike}
            aria-label="Ajouter aux favoris"
            type="button"
          />
        </div>
      </article>
    </Link>
  );
}
