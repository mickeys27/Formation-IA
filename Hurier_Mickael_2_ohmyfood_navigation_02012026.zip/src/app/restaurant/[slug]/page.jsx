import restaurantsData from "@/data/restaurants.json";
import { notFound } from "next/navigation";
import Image from "next/image";
import RestaurantHeader from "@/components/RestaurantHeader/RestaurantHeader";
import MenuItem from "@/components/MenuItem/MenuItem";
import styles from "./page.module.css";

export function generateStaticParams() {
  return restaurantsData.restaurants.map((r) => ({ slug: r.slug }));
}

export default async function RestaurantPage({ params }) {
  const { slug } = params;

  const restaurant = restaurantsData.restaurants.find((r) => r.slug === slug);
  if (!restaurant) notFound(); // etape 6 gérer les erreurs 404

  return (
    <main className={styles.page}>
       <div className={styles.hero}>
        <Image
          src={restaurant.image}
          alt={restaurant.name}
          fill
          className={styles.heroImage}
          priority
        />
      </div>
      <section className={styles.menuCard}>
      <RestaurantHeader name={restaurant.name} />
        <div className={styles.sections}>
          <div className={styles.menuSection}>
            <h2 className={styles.sectionTitle}>Entrées</h2>
            <div className={styles.sectionLine} />
            <div className={styles.items}>
              {restaurant.menu["entrées"].map((item, idx) => (
                <MenuItem key={`entree-${restaurant.id}-${idx}`} item={item} index={idx}/>
              ))}
            </div>
          </div>

          <div className={styles.menuSection}>
            <h2 className={styles.sectionTitle}>Plats</h2>
            <div className={styles.sectionLine} />
            <div className={styles.items}>
              {restaurant.menu["plats"].map((item, idx) => (
                <MenuItem
                  key={`plat-${restaurant.id}-${idx}`}
                  item={item}
                  index={idx}
                />
              ))}
            </div>
          </div>

          <div className={styles.menuSection}>
            <h2 className={styles.sectionTitle}>Desserts</h2>
            <div className={styles.sectionLine} />
            <div className={styles.items}>
              {restaurant.menu["desserts"].map((item, idx) => (
                <MenuItem
                  key={`dessert-${restaurant.id}-${idx}`}
                  item={item}
                  index={idx}
                />
              ))}
            </div>
          </div>
        </div>

        <div className={styles.orderWrap}>
          <button className={styles.orderBtn}>Commander</button>
        </div>
      </section>
    </main>
  );
}
