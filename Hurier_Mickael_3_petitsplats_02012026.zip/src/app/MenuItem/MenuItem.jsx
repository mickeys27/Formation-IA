
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCircleCheck } from '@fortawesome/free-solid-svg-icons';

export default function MenuItem({ item, index }) {
  return (
    <div className="menuItem" data-index={index}>
      <div className="menuItemContent">
        <h4>itemnom</h4>
        <p>itemdescription</p>
      </div>
      <span className="price">itemprix</span>
    </div>
  );
} 