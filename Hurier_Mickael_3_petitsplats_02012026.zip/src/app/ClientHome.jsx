"use client";

import { useState } from "react";
import Header from "../components/Header/Header";
import Filter from "../components/Filter/Filter";

export default function ClientHome({ recipes }) {
  const [searchTerm, setSearchTerm] = useState("");

  return (
    <>
      <Header searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      <Filter searchTerm={searchTerm} recipes={recipes} />
    </>
  );
}
