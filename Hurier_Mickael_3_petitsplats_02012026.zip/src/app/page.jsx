import ClientHome from "./ClientHome";
import { getRecipes } from "../app/lib/recipes";

export default function Page() {
  const recipes = getRecipes();
  return <ClientHome recipes={recipes} />;
}
