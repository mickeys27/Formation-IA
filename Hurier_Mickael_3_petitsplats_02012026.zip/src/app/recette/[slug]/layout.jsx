import Link from "next/link";
import styles from "./layout.module.css";

export default function Layout({ children }) {
  return (
    <section className={styles.Page}>
      <header className={styles.heroHeader}>
        <div className={styles.heroImageWrapper}>
        <img className={styles.heroImage} src="/images/header.jpg"  alt="Plat de cuisine"></img>        
      </div>
        <div className={styles.HeaderInner}>
          <div className={styles.brand}>
            <span className={styles.brandText}><Link href="/" className={styles.backLink}>LES PETITS PLATS</Link></span>
            <span className={styles.brandDot} aria-hidden="true" />
          </div>
        </div>
      </header>
      <main className={styles.Main}>{children}</main>
    </section>
  );
}