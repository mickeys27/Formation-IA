import recettesData from "../../../data/recipes.json";
import { notFound } from "next/navigation";
import Image from "next/image";
import styles from "./page.module.css";

export function generateStaticParams() {
  return recettesData.map((r) => ({ slug: r.slug }));
}

export default function RecettePage({ params }) {
  const slug = params?.slug;
  const recette = recettesData.find((r) => r.slug === slug);

  if (!recette) notFound();

  return (
    <main className={styles.recipe}>
      <section className={styles.recipeLayout}>
        {/* IMAGE (gauche) */}
        <figure className={styles.recipeMedia} aria-label="Image de la recette">
          {/* Si tu ne veux pas next/image, remplace par <img src=... /> */}
          <Image
            className={styles.recipeImage}
            src={`/images/${recette.image}`}
            alt={recette.name}
            width={720}
            height={720}
            priority
          />
        </figure>

        {/* CONTENU (droite) */}
        <article className={styles.recipeContent}>
          <header className={styles.recipeHeader}>
            {/* JSON -> recette.name */}
            <h1 className={styles.recipeTitle}>{recette.name}</h1>
          </header>

          {/* TEMPS */}
          <section className={styles.recipeSection} aria-labelledby="prep-time">
            <h2 id="prep-time" className={styles.sectionTitle}>
              TEMPS DE PRÉPARATION
            </h2>
            {/* JSON -> recette.time */}
            <span className={styles.pill}>{recette.time}min</span>
          </section>

          {/* INGREDIENTS */}
          <section className={styles.recipeSection} aria-labelledby="ingredients">
            <h2 id="ingredients" className={styles.sectionTitle}>
              INGRÉDIENTS
            </h2>

            <div className={styles.grid3}>
              {/* JSON -> recette.ingredients[] */}
              {recette.ingredients.map((item, idx) => (
                <div className={styles.kv} key={`${item.ingredient}-${idx}`}>
                  <div className={styles.kvName}>{item.ingredient}</div>

                  {/* quantity/unit optionnels */}
                  <div className={styles.kvValue}>
                    {item.quantity ? (
                      <>
                        {item.quantity}
                        {item.unit ? ` ${item.unit}` : ""}
                      </>
                    ) : (
                      <span className={styles.kvEmpty}>—</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* USTENSILES */}
          <section className={styles.recipeSection} aria-labelledby="ustensils">
            <h2 id="ustensils" className={styles.sectionTitle}>
              USTENSILES NÉCESSAIRES
            </h2>

            <div className={styles.list2}>
              {/* JSON -> recette.ustensils[] */}
              {recette.ustensils.map((u, idx) => (
                <div className={styles.kv} key={`${u}-${idx}`}>
                  <div className={styles.kvName}>{u}</div>
                  <div className={styles.kvValue}>1</div>
                </div>
              ))}
            </div>
          </section>

          {/* APPAREILS */}
          <section className={styles.recipeSection} aria-labelledby="appliances">
            <h2 id="appliances" className={styles.sectionTitle}>
              APPAREILS NÉCESSAIRES
            </h2>

            <div className={styles.list2}>
              {/* JSON -> recette.appliance */}
              <div className={styles.kv}>
                <div className={styles.kvName}>{recette.appliance}</div>
                <div className={styles.kvValue}>1</div>
              </div>
            </div>
          </section>

          {/* RECETTE / DESCRIPTION */}
          <section className={styles.recipeSection} aria-labelledby="recipe">
            <h2 id="recipe" className={styles.sectionTitle}>
              RECETTE
            </h2>

            {/* JSON -> recette.description (texte) */}
            <p className={styles.description}>{recette.description}</p>

            {/* Option: si tu veux garder un rendu "étapes", il faudra parser le texte en étapes.
               Pour l'instant c'est le JSON brut. */}
          </section>
        </article>
      </section>
    </main>
  );
}
