import Link from "next/link";
import styles from "./not-found.module.css";

export default function NotFound() {
  return (
     <header className={styles.heroHeader}>
      <div className={styles.heroImageWrapper}>
        <img className={styles.heroImage} src="/images/header.jpg"  alt="Plat de cuisine"></img>        
      </div>
      <div className={styles.heroContent}>
      <div className={styles.brand}>
        <span className={styles.brandText}><Link href="/" className={styles.backLink}>LES PETITS PLATS</Link></span>
        <span className={styles.brandDot} aria-hidden="true" />
      </div>
        <h1 className={styles.heroTitle}>404 :</h1>
        <p className={styles.heroSubtitle}>
          La page que vous demandez est introuvable.
        </p>
      </div>
</header>
  );
}
