"use client";
import Link from "next/link";
import Image from "next/image";
import styles from "./RecetteCard.module.css";


function formatQty(it) {
  if (!it.quantity) return "";
  return `${it.quantity}${it.unit ? ` ${it.unit}` : ""}`;
}

export default function RecetteCard({ recette }) {
  const { image, name, time, description, ingredients,slug } = recette;

  // images dans public/images/Recette01.jpg
  const imgSrc = image.startsWith("/images/") ? image : `/images/${image}`;

  return (
    <Link href={`/recette/${slug}`} className={styles.cardLink}>
    <article className={styles.card}>
      <div className={styles.imageWrapper}>
        <Image src={imgSrc} alt={name} fill className={styles.image} />
        <span className={styles.time}>{time}min</span>
      </div>

      <div className={styles.content}>
        <h3 className={styles.title}>{name}</h3>

        <div className={styles.block}>
          <p className={styles.label}>RECETTE</p>
          <p className={styles.description}>{description.length > 200 ? description.slice(0, 200) + "…" : description}</p>
        </div>
        <div className={styles.block}>
          <p className={styles.label}>INGRÉDIENTS</p>

          <ul className={styles.ingredients}>
            {ingredients.map((it, idx) => (
              <li key={`${it.ingredient}-${idx}`} className={styles.ingredient}>
                <span className={styles.ingredientName}>{it.ingredient}</span>
                <span className={styles.ingredientQty}>{formatQty(it)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </article>
    </Link>
  );
}
