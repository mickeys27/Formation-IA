'use client';
import Image from "next/image";
import styles from "./Hearder.module.css";

export default function Header({ searchTerm, setSearchTerm }) {  return (
    <header className={styles.heroHeader}>

      <div className={styles.heroImageWrapper}>
        <img className={styles.heroImage} src="/images/header.jpg"  alt="Plat de cuisine"></img>        
      </div>

        <div className={styles.heroContent}>
        <div className={styles.brand}>
          <span className={styles.brandText}>LES PETITS PLATS</span>
          <span className={styles.brandDot} aria-hidden="true" />
        </div>

        <h1 className={styles.heroTitle}>DÉCOUVREZ NOS RECETTES</h1>
        <p className={styles.heroSubtitle}>
          Du quotidien, simples et délicieuses
        </p>

        {/* Barre de recherche principale */}
        <section className={styles.searchBar}>
          <input
            type="text"
            className={styles.searchInput}
            placeholder="Rechercher une recette, un ingrédient..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm.length > 0 && searchTerm.length < 3 && (
            <small className="search-hint">
              Entrez au moins 3 caractères pour rechercher
            </small>
          )}
          <button className={styles.searchBtn} type="submit" aria-label="Rechercher">
           <svg width="51" height="52" viewBox="0 0 51 52" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="51" height="52" rx="10" fill="#1B1B1B"/>
            <circle cx="22" cy="22" r="9.5" stroke="white"/>
            <line x1="30.3536" y1="30.6464" x2="39.3536" y2="39.6464" stroke="white"/>
            </svg>

          </button> 
        </section>


{/*         <form className={styles.searchBar} role="search">
          <input
            className={styles.searchInput}
            type="search"
            placeholder="Rechercher une recette, un ingrédient, ..."
            aria-label="Rechercher une recette"
          />
          <button className={styles.searchBtn} type="submit" aria-label="Rechercher">
           <svg width="51" height="52" viewBox="0 0 51 52" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="51" height="52" rx="10" fill="#1B1B1B"/>
            <circle cx="22" cy="22" r="9.5" stroke="white"/>
            <line x1="30.3536" y1="30.6464" x2="39.3536" y2="39.6464" stroke="white"/>
            </svg>

          </button> 
        </form>*/}
  </div>
</header>

  );
}



