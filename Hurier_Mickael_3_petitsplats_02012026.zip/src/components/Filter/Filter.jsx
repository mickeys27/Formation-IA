"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import styles from "./Filter.module.css";
import RecetteCard from "../RecetteCard/RecetteCard";

const includesInsensitive = (value, query) =>
  value.toLowerCase().includes(query.toLowerCase());

function FilterDropdown({ label, value, options, placeholder = "Rechercher...", onChange }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const rootRef = useRef(null);

  useEffect(() => {
    const onDocClick = (e) => {
      if (!rootRef.current) return;
      if (!rootRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  useEffect(() => {
    if (!open) setQuery("");
  }, [open]);

  const filteredOptions = useMemo(() => {
    const q = query.trim();
    if (!q) return options;
    return options.filter((opt) => includesInsensitive(opt, q));
  }, [options, query]);

  const displayText = value || label;

  return (
    <div className={styles.dropdown} ref={rootRef}>
      <button
        type="button"
        className={`${styles.dropdownButton} ${open ? styles.isOpen : ""}`}
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span className={styles.dropdownButtonText}>{displayText}</span>
        <span className={styles.chevron} aria-hidden="true">
          {open ? "▴" : "▾"}
        </span>
      </button>

      {open && (
        <div className={styles.dropdownPanel}>
          <div className={styles.searchRow}>
            <input
              className={styles.searchInput}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={placeholder}
              autoFocus
            />

            {query.length > 0 && (
              <button
                type="button"
                className={styles.clearBtn}
                onClick={() => setQuery("")}
                aria-label="Effacer la recherche"
              >
                ×
              </button>
            )}

            <span className={styles.searchIcon} aria-hidden="true">
              🔍
            </span>
          </div>

          <ul className={styles.optionsList} role="listbox">
            {filteredOptions.length === 0 ? (
              <li className={styles.noOption}>Aucun résultat</li>
            ) : (
              filteredOptions.map((opt) => {
                const selected = opt === value;
                return (
                  <li key={opt}>
                    <button
                      type="button"
                      className={`${styles.optionBtn} ${selected ? styles.optionSelected : ""}`}
                      onClick={() => {
                        onChange(opt);
                        setOpen(false);
                      }}
                      role="option"
                      aria-selected={selected}
                    >
                      {opt}
                    </button>
                  </li>
                );
              })
            )}
          </ul>

          {value && (
            <button
              type="button"
              className={styles.resetSelection}
              onClick={() => {
                onChange("");
                setOpen(false);
              }}
            >
              Réinitialiser
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export default function Filter({ searchTerm = "", recipes = [] }) {
  const [selectedFilters, setSelectedFilters] = useState({
    ingredients: "",
    appliances: "",
    ustensils: "",
  });

  const filteredRecipes = useMemo(() => {
    const term = (searchTerm ?? "").trim();

    return recipes.filter((recette) => {
      if (term.length >= 3) {
        const search = term.toLowerCase();

        const matchName = (recette.name ?? "").toLowerCase().includes(search);
        const matchIngredients = (recette.ingredients ?? []).some((i) =>
          (i.ingredient ?? "").toLowerCase().includes(search)
        );
        const matchDescription = (recette.description ?? "").toLowerCase().includes(search);

        if (!matchName && !matchIngredients && !matchDescription) return false;
      }

      if (selectedFilters.ingredients) {
        const hasIngredient = (recette.ingredients ?? []).some(
          (i) => i.ingredient === selectedFilters.ingredients
        );
        if (!hasIngredient) return false;
      }

      if (selectedFilters.appliances) {
        if (recette.appliance !== selectedFilters.appliances) return false;
      }

      if (selectedFilters.ustensils) {
        if (!(recette.ustensils ?? []).includes(selectedFilters.ustensils)) return false;
      }

      return true;
    });
  }, [recipes, searchTerm, selectedFilters]);

  const filterOptions = useMemo(() => {
    const ingredients = [
      ...new Set(
        filteredRecipes.flatMap((r) =>
          (r.ingredients ?? []).map((i) => i.ingredient).filter(Boolean)
        )
      ),
    ].sort((a, b) => a.localeCompare(b, "fr"));

    const appliances = [
      ...new Set(filteredRecipes.map((r) => r.appliance).filter(Boolean)),
    ].sort((a, b) => a.localeCompare(b, "fr"));

    const ustensils = [
      ...new Set(filteredRecipes.flatMap((r) => (r.ustensils ?? []).filter(Boolean))),
    ].sort((a, b) => a.localeCompare(b, "fr"));

    return { ingredients, appliances, ustensils };
  }, [filteredRecipes]);

  return (
    <div className="app-container">
      <main className="app-main">
        <section className="filters-section">
          <div className={styles.filtersBar}>
            <div className={styles.filtersContainer}>
              <FilterDropdown
                label="Ingrédients"
                value={selectedFilters.ingredients}
                options={filterOptions.ingredients}
                placeholder="Rechercher un ingrédient"
                onChange={(val) => setSelectedFilters((prev) => ({ ...prev, ingredients: val }))}
              />

              <FilterDropdown
                label="Appareils"
                value={selectedFilters.appliances}
                options={filterOptions.appliances}
                placeholder="Rechercher un appareil"
                onChange={(val) => setSelectedFilters((prev) => ({ ...prev, appliances: val }))}
              />

              <FilterDropdown
                label="Ustensiles"
                value={selectedFilters.ustensils}
                options={filterOptions.ustensils}
                placeholder="Rechercher un ustensile"
                onChange={(val) => setSelectedFilters((prev) => ({ ...prev, ustensils: val }))}
              />
            </div>

            <div className={styles.recipesCount}>
              <span className={styles.countText}>
                {filteredRecipes.length} recette{filteredRecipes.length > 1 ? "s" : ""}
              </span>
            </div>
          </div>
        </section>

        {filteredRecipes.length === 0 ? (
          <div className="no-results">
            <p className="no-results-text">
              {(searchTerm ?? "").trim().length >= 3
                ? `Aucune recette ne contient '${searchTerm}'`
                : "Aucune recette trouvée avec ces filtres"}
            </p>
          </div>
        ) : (
          <div className={styles.recetteGrid}>
            {filteredRecipes.map((recette) => (
              <RecetteCard key={recette.id} recette={recette} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
